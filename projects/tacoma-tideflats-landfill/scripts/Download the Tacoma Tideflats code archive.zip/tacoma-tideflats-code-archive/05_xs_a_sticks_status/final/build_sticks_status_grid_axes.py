# -*- coding: utf-8 -*-
# NOTE: Extracted and normalized from Landfill Master Document.docx.
# Archive status: final available version for this category. Review configuration before execution.
# Public-safe copy: internal emails, user paths, and organization-specific locations were removed.

"""
Build only XS_A depth sticks, status blocks, grid, axes, and feet labels.
Run this entire script in a new ArcGIS Pro notebook cell.
Required existing layer
-----------------------
PT_50 Location Dots - Status
Required fields
---------------
REPORT_ID
TOTAL_DEPTH_FT
HAS_DEPTH
LOCATION_STATUS
Optional fields
---------------
POINT_KEY
STATION_FT
Outputs
-------
PT_40 Investigation Depth Sticks
PT_41 Location Status Blocks
PT_60 Measured Grid
PT_61 Axes
PT_62 Horizontal Distance Labels
PT_63 Vertical Depth Labels
PT_64 Axis Titles
Notes
-----
- The existing location dots are not modified.
- Existing Report ID label layers are not modified.
- Only points with a valid depth receive sticks and blocks.
- Blocks are symbolized by LOCATION_STATUS.
- Existing output feature classes are not deleted.
- New uniquely named feature classes are created on each run.
"""
import os
import re
import math
import traceback
import arcpy
arcpy.env.overwriteOutput = False
# =============================================================================
# SOURCE MAP AND LAYER
# =============================================================================
MAP_NAME = "XSEC_XS_A"
DOTS_LAYER_NAME = (
"PT_50 Location Dots - Status"
)
SAVE_PROJECT = True
# =============================================================================
# CROSS-SECTION SETTINGS
# =============================================================================
VERTICAL_EXAGGERATION = 5.0
HORIZONTAL_INTERVAL_FT = 100.0
DEPTH_INTERVAL_FT = 5.0
MIN_DISPLAY_DEPTH_FT = 10.0
BOTTOM_PADDING_FT = 5.0
MAX_REASONABLE_DEPTH_FT = 300.0
# Half-width of each status block.
# A value of 5 creates a 10-foot-wide block.
BLOCK_HALF_WIDTH_FT = 5.0
# =============================================================================
# OUTPUT LAYER NAMES
# =============================================================================
STICKS_LAYER_NAME = (
"PT_40 Investigation Depth Sticks"
)
BLOCKS_LAYER_NAME = (
"PT_41 Location Status Blocks"
)
GRID_LAYER_NAME = (
"PT_60 Measured Grid"
)
AXES_LAYER_NAME = (
"PT_61 Axes"
)
DISTANCE_LABELS_LAYER_NAME = (
"PT_62 Horizontal Distance Labels"
)
DEPTH_LABELS_LAYER_NAME = (
"PT_63 Vertical Depth Labels"
)
TITLES_LAYER_NAME = (
"PT_64 Axis Titles"
)
# =============================================================================
# COLORS
# =============================================================================
STICK_COLOR = (
0,
0,
0,
100
)
GRID_COLOR = (
210,
210,
210,
45
)
AXIS_COLOR = (
40,
40,
40,
100
)
BLOCK_COLORS = {
"CLEANED_UP": (
52,
168,
83,
45
),
"EXCEEDS": (
220,
40,
40,
45
),
"NO_DATA": (
150,
150,
150,
35
)
}
# =============================================================================
# MESSAGE AND TEXT HELPERS
# =============================================================================
def message(text, severity=0):
"""Write a message to ArcGIS Pro and the notebook."""
text = str(text)
if severity == 2:
arcpy.AddError(text)
elif severity == 1:
arcpy.AddWarning(text)
else:
arcpy.AddMessage(text)
print(text)
def clean_text(value):
"""Convert a value into clean text."""
if value is None:
return ""
text = str(value).strip()
if text.lower() in (
"",
"none",
"null",
"nan"
):
return ""
return text
def rgba(color):
"""Convert a color tuple into an ArcGIS Pro color dictionary."""
return {
"RGB": list(color)
}
# =============================================================================
# PROJECT HELPERS
# =============================================================================
def find_map(project, name):
"""Find a map by its exact name."""
matching_maps = project.listMaps(
name
)
if not matching_maps:
raise ValueError(
"Map '{}' was not found.".format(
name
)
)
return matching_maps[0]
def find_layer(map_object, name):
"""Find a layer by its exact displayed name."""
for layer in map_object.listLayers():
if (
layer.name.strip().lower()
== name.strip().lower()
):
return layer
raise ValueError(
"Layer '{}' was not found in map '{}'.".format(
name,
map_object.name
)
)
def find_field(
dataset,
candidates,
required=True
):
"""Find the first matching field by name or alias."""
fields = arcpy.ListFields(
dataset
)
for candidate in candidates:
for field in fields:
if (
field.name.lower()
== candidate.lower()
):
return field.name
if (
str(field.aliasName).lower()
== candidate.lower()
):
return field.name
if required:
raise ValueError(
"Missing field {}. Available fields: {}.".format(
candidates,
[
field.name
for field in fields
]
)
)
return None
def get_geodatabase(dataset_path):
"""
Find the file geodatabase containing a dataset.
This works if the dataset is stored directly in the geodatabase or
inside a feature dataset.
"""
current_path = dataset_path
while current_path:
if current_path.lower().endswith(
".gdb"
):
return current_path
parent_path = os.path.dirname(
current_path
)
if (
not parent_path
or parent_path == current_path
):
break
current_path = parent_path
raise ValueError(
"Could not find the containing geodatabase for: {}".format(
dataset_path
)
)
def remove_old_layer(
map_object,
layer_name
):
"""
Remove an old displayed layer.
Its underlying feature class is not deleted.
"""
for layer in list(
map_object.listLayers()
):
if (
layer.name.strip().lower()
!= layer_name.strip().lower()
):
continue
try:
map_object.removeLayer(
layer
)
except Exception as error:
message(
"Could not remove old layer '{}': {}".format(
layer_name,
error
),
1
)
# =============================================================================
# OUTPUT HELPERS
# =============================================================================
def unique_output(
workspace,
base_name
):
"""
Return a unique output name and path.
Existing feature classes are not deleted.
"""
validated_base_name = (
arcpy.ValidateTableName(
base_name,
workspace
)
)
output_name = validated_base_name
output_path = os.path.join(
workspace,
output_name
)
counter = 2
while arcpy.Exists(output_path):
output_name = (
arcpy.ValidateTableName(
"{}_{}".format(
validated_base_name,
counter
),
workspace
)
)
output_path = os.path.join(
workspace,
output_name
)
counter += 1
return output_name, output_path
def create_feature_class(
workspace,
base_name,
geometry_type,
spatial_reference,
fields
):
"""Create a uniquely named output feature class."""
(
output_name,
output_path
) = unique_output(
workspace,
base_name
)
arcpy.management.CreateFeatureclass(
out_path=workspace,
out_name=output_name,
geometry_type=geometry_type,
spatial_reference=(
spatial_reference
)
)
for (
field_name,
field_type,
field_length
) in fields:
parameters = {}
if (
field_type == "TEXT"
and field_length
):
parameters[
"field_length"
] = field_length
arcpy.management.AddField(
in_table=output_path,
field_name=field_name,
field_type=field_type,
**parameters
)
message(
"Created: {}".format(
output_path
)
)
return output_path
# =============================================================================
# DEPTH AND STATUS HELPERS
# =============================================================================
def parse_depth(value):
"""
Extract a usable depth value.
Examples
--------
12.0 -> 12.0
12 ft -> 12.0
3-13 ft -> 13.0
Unknown -> None
"""
if value is None:
return None
if isinstance(value, (int, float)):
numeric_value = float(value)
if (
numeric_value > 0
and numeric_value
<= MAX_REASONABLE_DEPTH_FT
):
return numeric_value
return None
text = clean_text(value)
number_strings = re.findall(
r"-?\d+(?:\.\d+)?",
text.replace(",", "")
)
depths = []
for number_string in number_strings:
depth = float(number_string)
if (
depth > 0
and depth
<= MAX_REASONABLE_DEPTH_FT
):
depths.append(depth)
if not depths:
return None
return max(depths)
def has_depth(
value,
parsed_depth
):
"""Interpret HAS_DEPTH and confirm that a numeric depth exists."""
if parsed_depth is None:
return False
if value is None:
return True
if isinstance(value, (int, float)):
return int(value) == 1
text = clean_text(
value
).upper()
if not text:
return True
return text in (
"1",
"YES",
"Y",
"TRUE",
"WITH_DEPTH"
)
def normalize_status(value):
"""Normalize a location status for block symbology."""
text = clean_text(
value
).upper()
if (
"EXCEED" in text
or "CONTAMINAT" in text
):
return "EXCEEDS"
if (
"CLEAN" in text
or "REMEDIAT" in text
):
return "CLEANED_UP"
return "NO_DATA"
# =============================================================================
# GEOMETRY HELPERS
# =============================================================================
def create_line(
x1,
y1,
x2,
y2,
spatial_reference
):
"""Create a two-point polyline."""
return arcpy.Polyline(
arcpy.Array([
arcpy.Point(
x1,
y1
),
arcpy.Point(
x2,
y2
)
]),
spatial_reference
)
def create_status_block(
station,
depth,
spatial_reference
):
"""
Create a rectangular block from ground surface to total depth.
"""
bottom_y = (
-depth
* VERTICAL_EXAGGERATION
)
points = arcpy.Array([
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
bottom_y
),
arcpy.Point(
station + BLOCK_HALF_WIDTH_FT,
bottom_y
),
arcpy.Point(
station + BLOCK_HALF_WIDTH_FT,
0.0
),
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
0.0
),
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
bottom_y
)
])
return arcpy.Polygon(
points,
spatial_reference
)
# =============================================================================
# READ LOCATION DOTS
# =============================================================================
def load_locations(dots_layer):
"""
Read all stations and all locations with valid depth.
The complete station range is used for the horizontal axis.
Only valid depth locations receive sticks and blocks.
"""
data_source = (
dots_layer.dataSource
)
report_id_field = find_field(
data_source,
[
"REPORT_ID",
"ReportID",
"WELLID"
],
required=True
)
depth_field = find_field(
data_source,
[
"TOTAL_DEPTH_FT",
"DEPTH_FT",
"DEPTH"
],
required=True
)
has_depth_field = find_field(
data_source,
[
"HAS_DEPTH"
],
required=False
)
station_field = find_field(
data_source,
[
"STATION_FT"
],
required=False
)
point_key_field = find_field(
data_source,
[
"POINT_KEY"
],
required=False
)
status_field = find_field(
data_source,
[
"LOCATION_STATUS",
"STATUS"
],
required=False
)
search_fields = [
report_id_field,
depth_field
]
indexes = {}
optional_fields = (
(
"has_depth",
has_depth_field
),
(
"station",
station_field
),
(
"point_key",
point_key_field
),
(
"status",
status_field
)
)
for key, field_name in optional_fields:
if field_name:
indexes[key] = len(
search_fields
)
search_fields.append(
field_name
)
shape_index = len(
search_fields
)
search_fields.append(
"SHAPE@"
)
all_stations = []
depth_locations = []
with arcpy.da.SearchCursor(
data_source,
search_fields
) as cursor:
for row_number, row in enumerate(
cursor,
start=1
):
geometry = row[
shape_index
]
if (
geometry is None
or geometry.firstPoint is None
):
continue
if "station" in indexes:
station_value = row[
indexes["station"]
]
try:
station = float(
station_value
)
except Exception:
station = (
geometry.firstPoint.X
)
else:
station = (
geometry.firstPoint.X
)
all_stations.append(
station
)
depth = parse_depth(
row[1]
)
if "has_depth" in indexes:
has_depth_value = row[
indexes["has_depth"]
]
else:
has_depth_value = None
if not has_depth(
has_depth_value,
depth
):
continue
if "point_key" in indexes:
point_key = clean_text(
row[
indexes["point_key"]
]
)
else:
point_key = (
"POINT_{}".format(
row_number
)
)
if "status" in indexes:
status = normalize_status(
row[
indexes["status"]
]
)
else:
status = "NO_DATA"
depth_locations.append({
"report_id": clean_text(
row[0]
),
"point_key": point_key,
"station": station,
"depth": depth,
"status": status
})
if not all_stations:
raise ValueError(
"The location-dot layer contains no usable point geometry."
)
if not depth_locations:
raise ValueError(
"No features with valid depth were found. "
"Check HAS_DEPTH and TOTAL_DEPTH_FT."
)
depth_locations.sort(
key=lambda item: item["station"]
)
return (
all_stations,
depth_locations
)
# =============================================================================
# CREATE OUTPUT FEATURE CLASSES
# =============================================================================
def create_outputs(
workspace,
spatial_reference
):
"""Create all required output feature classes."""
sticks_fc = create_feature_class(
workspace,
"XS_A_Depth_Sticks",
"POLYLINE",
spatial_reference,
[
(
"REPORT_ID",
"TEXT",
100
),
(
"POINT_KEY",
"TEXT",
255
),
(
"STATION_FT",
"DOUBLE",
None
),
(
"DEPTH_FT",
"DOUBLE",
None
),
(
"LOCATION_STATUS",
"TEXT",
30
)
]
)
blocks_fc = create_feature_class(
workspace,
"XS_A_Status_Blocks",
"POLYGON",
spatial_reference,
[
(
"REPORT_ID",
"TEXT",
100
),
(
"POINT_KEY",
"TEXT",
255
),
(
"STATION_FT",
"DOUBLE",
None
),
(
"TOP_FT",
"DOUBLE",
None
),
(
"BOTTOM_FT",
"DOUBLE",
None
),
(
"LOCATION_STATUS",
"TEXT",
30
)
]
)
grid_fc = create_feature_class(
workspace,
"XS_A_Measured_Grid",
"POLYLINE",
spatial_reference,
[
(
"GRID_TYPE",
"TEXT",
30
),
(
"MEASURE_FT",
"DOUBLE",
None
)
]
)
axes_fc = create_feature_class(
workspace,
"XS_A_Axes",
"POLYLINE",
spatial_reference,
[
(
"AXIS_TYPE",
"TEXT",
40
)
]
)
distance_labels_fc = (
create_feature_class(
workspace,
"XS_A_Distance_Labels",
"POINT",
spatial_reference,
[
(
"LABEL",
"TEXT",
60
),
(
"DISTANCE_FT",
"DOUBLE",
None
)
]
)
)
depth_labels_fc = create_feature_class(
workspace,
"XS_A_Depth_Labels",
"POINT",
spatial_reference,
[
(
"LABEL",
"TEXT",
60
),
(
"DEPTH_FT",
"DOUBLE",
None
)
]
)
titles_fc = create_feature_class(
workspace,
"XS_A_Axis_Titles",
"POINT",
spatial_reference,
[
(
"LABEL",
"TEXT",
120
),
(
"TITLE_TYPE",
"TEXT",
30
)
]
)
return (
sticks_fc,
blocks_fc,
grid_fc,
axes_fc,
distance_labels_fc,
depth_labels_fc,
titles_fc
)
# =============================================================================
# BUILD OUTPUT ROWS
# =============================================================================
def build_rows(
all_stations,
locations,
spatial_reference
):
"""Build all stick, block, grid, axis, and label rows."""
minimum_station = min(
0.0,
min(all_stations)
)
maximum_station = max(
all_stations
)
maximum_depth = max(
MIN_DISPLAY_DEPTH_FT,
max(
location["depth"]
for location in locations
)
)
displayed_depth = (
math.ceil(
(
maximum_depth
+ BOTTOM_PADDING_FT
)
/ DEPTH_INTERVAL_FT
)
* DEPTH_INTERVAL_FT
)
bottom_y = (
-displayed_depth
* VERTICAL_EXAGGERATION
)
# -------------------------------------------------------------------------
# Depth sticks and status blocks
# -------------------------------------------------------------------------
stick_rows = []
block_rows = []
for location in locations:
station = location[
"station"
]
depth = location[
"depth"
]
stick_geometry = create_line(
station,
0.0,
station,
-depth * VERTICAL_EXAGGERATION,
spatial_reference
)
block_geometry = (
create_status_block(
station,
depth,
spatial_reference
)
)
stick_rows.append([
location["report_id"],
location["point_key"],
station,
depth,
location["status"],
stick_geometry
])
block_rows.append([
location["report_id"],
location["point_key"],
station,
0.0,
depth,
location["status"],
block_geometry
])
# -------------------------------------------------------------------------
# Horizontal distance grid
# -------------------------------------------------------------------------
grid_rows = []
distance_label_rows = []
station_measure = 0.0
while (
station_measure
<= maximum_station + 0.001
):
grid_rows.append([
"DISTANCE",
station_measure,
create_line(
station_measure,
0.0,
station_measure,
bottom_y,
spatial_reference
)
])
distance_label_rows.append([
"{} ft".format(
int(
round(
station_measure
)
)
),
station_measure,
arcpy.PointGeometry(
arcpy.Point(
station_measure,
bottom_y - 8.0
),
spatial_reference
)
])
station_measure += (
HORIZONTAL_INTERVAL_FT
)
last_station = (
station_measure
- HORIZONTAL_INTERVAL_FT
)
if (
maximum_station
- last_station
> 1.0
):
grid_rows.append([
"DISTANCE",
maximum_station,
create_line(
maximum_station,
0.0,
maximum_station,
bottom_y,
spatial_reference
)
])
distance_label_rows.append([
"{} ft".format(
int(
round(
maximum_station
)
)
),
maximum_station,
arcpy.PointGeometry(
arcpy.Point(
maximum_station,
bottom_y - 8.0
),
spatial_reference
)
])
# -------------------------------------------------------------------------
# Vertical depth grid
# -------------------------------------------------------------------------
depth_label_rows = []
depth_measure = 0.0
while (
depth_measure
<= displayed_depth + 0.001
):
depth_y = (
-depth_measure
* VERTICAL_EXAGGERATION
)
grid_rows.append([
"DEPTH",
depth_measure,
create_line(
minimum_station,
depth_y,
maximum_station,
depth_y,
spatial_reference
)
])
depth_label_rows.append([
"{} ft bgs".format(
int(
round(
depth_measure
)
)
),
depth_measure,
arcpy.PointGeometry(
arcpy.Point(
minimum_station - 12.0,
depth_y
),
spatial_reference
)
])
depth_measure += (
DEPTH_INTERVAL_FT
)
# -------------------------------------------------------------------------
# Main axes
# -------------------------------------------------------------------------
axes_rows = [
[
"GROUND_SURFACE",
create_line(
minimum_station,
0.0,
maximum_station,
0.0,
spatial_reference
)
],
[
"DEPTH_AXIS",
create_line(
minimum_station,
0.0,
minimum_station,
bottom_y,
spatial_reference
)
],
[
"DISTANCE_AXIS",
create_line(
minimum_station,
bottom_y,
maximum_station,
bottom_y,
spatial_reference
)
]
]
# -------------------------------------------------------------------------
# Axis titles
# -------------------------------------------------------------------------
title_rows = [
[
"Distance Along XS_A (ft)",
"HORIZONTAL",
arcpy.PointGeometry(
arcpy.Point(
(
minimum_station
+ maximum_station
)
/ 2.0,
bottom_y - 25.0
),
spatial_reference
)
],
[
"Depth Below Ground Surface (ft)",
"VERTICAL",
arcpy.PointGeometry(
arcpy.Point(
minimum_station - 30.0,
bottom_y / 2.0
),
spatial_reference
)
],
[
"XS_A | {}x Vertical Exaggeration".format(
int(
VERTICAL_EXAGGERATION
)
),
"TITLE",
arcpy.PointGeometry(
arcpy.Point(
(
minimum_station
+ maximum_station
)
/ 2.0,
25.0
),
spatial_reference
)
]
]
return (
stick_rows,
block_rows,
grid_rows,
axes_rows,
distance_label_rows,
depth_label_rows,
title_rows,
minimum_station,
maximum_station,
bottom_y
)
# =============================================================================
# WRITE OUTPUT ROWS
# =============================================================================
def insert_rows(
dataset,
fields,
rows
):
"""Write rows with one insert cursor."""
with arcpy.da.InsertCursor(
dataset,
fields
) as cursor:
for row in rows:
cursor.insertRow(row)
# =============================================================================
# LAYER STYLING
# =============================================================================
def style_line(
layer,
color,
width
):
"""Apply simple line symbology."""
try:
symbology = layer.symbology
symbol = symbology.renderer.symbol
symbol.color = rgba(
color
)
if hasattr(
symbol,
"size"
):
symbol.size = width
symbology.renderer.symbol = (
symbol
)
layer.symbology = symbology
except Exception as error:
message(
"Line styling warning for '{}': {}".format(
layer.name,
error
),
1
)
def style_blocks(layer):
"""Apply unique-value symbology using LOCATION_STATUS."""
try:
symbology = layer.symbology
symbology.updateRenderer(
"UniqueValueRenderer"
)
symbology.renderer.fields = [
"LOCATION_STATUS"
]
layer.symbology = symbology
symbology = layer.symbology
for renderer_group in (
symbology.renderer.groups
):
for item in renderer_group.items:
status_value = str(
item.values[0][0]
)
color = BLOCK_COLORS.get(
status_value,
BLOCK_COLORS["NO_DATA"]
)
item.symbol.color = rgba(
color
)
if hasattr(
item.symbol,
"outlineColor"
):
item.symbol.outlineColor = (
rgba(
(
75,
75,
75,
55
)
)
)
if status_value == "CLEANED_UP":
item.label = "Cleaned Up"
elif status_value == "EXCEEDS":
item.label = "Exceeds"
elif status_value == "NO_DATA":
item.label = "No Data"
layer.symbology = symbology
except Exception as error:
message(
"Block styling warning: {}".format(
error
),
1
)
def configure_labels(layer):
"""Hide helper point markers and label using LABEL."""
try:
symbology = layer.symbology
symbol = symbology.renderer.symbol
symbol.color = rgba(
(
255,
255,
255,
0
)
)
if hasattr(
symbol,
"outlineColor"
):
symbol.outlineColor = rgba(
(
255,
255,
255,
0
)
)
if hasattr(
symbol,
"size"
):
symbol.size = 0.1
symbology.renderer.symbol = (
symbol
)
layer.symbology = symbology
except Exception as error:
message(
"Helper marker warning for '{}': {}".format(
layer.name,
error
),
1
)
if layer.supports(
"SHOWLABELS"
):
layer.showLabels = True
for label_class in (
layer.listLabelClasses()
):
label_class.expressionEngine = (
"Arcade"
)
label_class.expression = (
"$feature.LABEL"
)
label_class.visible = True
# =============================================================================
# ADD LAYERS TO MAP
# =============================================================================
def add_layers(
map_object,
outputs
):
"""Add and style all output layers."""
displayed_names = [
STICKS_LAYER_NAME,
BLOCKS_LAYER_NAME,
GRID_LAYER_NAME,
AXES_LAYER_NAME,
DISTANCE_LABELS_LAYER_NAME,
DEPTH_LABELS_LAYER_NAME,
TITLES_LAYER_NAME
]
for displayed_name in displayed_names:
remove_old_layer(
map_object,
displayed_name
)
(
sticks_fc,
blocks_fc,
grid_fc,
axes_fc,
distance_labels_fc,
depth_labels_fc,
titles_fc
) = outputs
# Grid.
grid_layer = (
map_object.addDataFromPath(
grid_fc
)
)
grid_layer.name = GRID_LAYER_NAME
style_line(
grid_layer,
GRID_COLOR,
0.4
)
# Status blocks.
blocks_layer = (
map_object.addDataFromPath(
blocks_fc
)
)
blocks_layer.name = (
BLOCKS_LAYER_NAME
)
style_blocks(
blocks_layer
)
# Depth sticks.
sticks_layer = (
map_object.addDataFromPath(
sticks_fc
)
)
sticks_layer.name = (
STICKS_LAYER_NAME
)
style_line(
sticks_layer,
STICK_COLOR,
1.1
)
# Axes.
axes_layer = (
map_object.addDataFromPath(
axes_fc
)
)
axes_layer.name = AXES_LAYER_NAME
style_line(
axes_layer,
AXIS_COLOR,
1.2
)
# Horizontal distance labels.
distance_layer = (
map_object.addDataFromPath(
distance_labels_fc
)
)
distance_layer.name = (
DISTANCE_LABELS_LAYER_NAME
)
configure_labels(
distance_layer
)
# Vertical depth labels.
depth_layer = (
map_object.addDataFromPath(
depth_labels_fc
)
)
depth_layer.name = (
DEPTH_LABELS_LAYER_NAME
)
configure_labels(
depth_layer
)
# Axis titles.
titles_layer = (
map_object.addDataFromPath(
titles_fc
)
)
titles_layer.name = (
TITLES_LAYER_NAME
)
configure_labels(
titles_layer
)
# =============================================================================
# MAIN
# =============================================================================
def main():
message(
"Building XS_A sticks, status blocks, grid, and axes."
)
project = arcpy.mp.ArcGISProject(
"CURRENT"
)
map_object = find_map(
project,
MAP_NAME
)
dots_layer = find_layer(
map_object,
DOTS_LAYER_NAME
)
dots_source = (
dots_layer.dataSource
)
workspace = get_geodatabase(
dots_source
)
spatial_reference = (
arcpy.Describe(
dots_source
).spatialReference
)
message(
"Using location-dot source:"
)
message(
dots_source
)
message(
"Writing outputs to:"
)
message(
workspace
)
# Read the existing location dots.
(
all_stations,
depth_locations
) = load_locations(
dots_layer
)
message(
"Locations with valid depth: {}".format(
len(depth_locations)
)
)
# Create new output feature classes.
outputs = create_outputs(
workspace,
spatial_reference
)
# Build geometry and label rows.
rows = build_rows(
all_stations,
depth_locations,
spatial_reference
)
(
stick_rows,
block_rows,
grid_rows,
axes_rows,
distance_rows,
depth_rows,
title_rows,
minimum_station,
maximum_station,
bottom_y
) = rows
(
sticks_fc,
blocks_fc,
grid_fc,
axes_fc,
distance_labels_fc,
depth_labels_fc,
titles_fc
) = outputs
# Write the depth sticks.
insert_rows(
sticks_fc,
[
"REPORT_ID",
"POINT_KEY",
"STATION_FT",
"DEPTH_FT",
"LOCATION_STATUS",
"SHAPE@"
],
stick_rows
)
# Write the status blocks.
insert_rows(
blocks_fc,
[
"REPORT_ID",
"POINT_KEY",
"STATION_FT",
"TOP_FT",
"BOTTOM_FT",
"LOCATION_STATUS",
"SHAPE@"
],
block_rows
)
# Write the measured grid.
insert_rows(
grid_fc,
[
"GRID_TYPE",
"MEASURE_FT",
"SHAPE@"
],
grid_rows
)
# Write the main axes.
insert_rows(
axes_fc,
[
"AXIS_TYPE",
"SHAPE@"
],
axes_rows
)
# Write horizontal distance labels.
insert_rows(
distance_labels_fc,
[
"LABEL",
"DISTANCE_FT",
"SHAPE@"
],
distance_rows
)
# Write vertical depth labels.
insert_rows(
depth_labels_fc,
[
"LABEL",
"DEPTH_FT",
"SHAPE@"
],
depth_rows
)
# Write axis titles.
insert_rows(
titles_fc,
[
"LABEL",
"TITLE_TYPE",
"SHAPE@"
],
title_rows
)
# Validate basic output counts.
written_stick_count = int(
arcpy.management.GetCount(
sticks_fc
)[0]
)
written_block_count = int(
arcpy.management.GetCount(
blocks_fc
)[0]
)
written_grid_count = int(
arcpy.management.GetCount(
grid_fc
)[0]
)
written_axis_count = int(
arcpy.management.GetCount(
axes_fc
)[0]
)
if written_stick_count == 0:
raise ValueError(
"No depth sticks were written."
)
if (
written_stick_count
!= written_block_count
):
raise ValueError(
"Stick count {} does not match block count {}.".format(
written_stick_count,
written_block_count
)
)
if written_grid_count == 0:
raise ValueError(
"No grid lines were written."
)
if written_axis_count != 3:
raise ValueError(
"Expected 3 axes, but {} were written.".format(
written_axis_count
)
)
# Add and style the output layers.
add_layers(
map_object,
outputs
)
# Set a useful map extent.
try:
map_object.defaultCamera.setExtent(
arcpy.Extent(
minimum_station - 45.0,
bottom_y - 40.0,
maximum_station + 20.0,
35.0
)
)
except Exception as error:
message(
"Extent warning: {}".format(
error
),
1
)
if SAVE_PROJECT:
project.save()
message("")
message("=" * 72)
message("XS_A STICKS, BLOCKS, AND AXES COMPLETE")
message("=" * 72)
message(
"Depth sticks created: {}".format(
len(stick_rows)
)
)
message(
"Status blocks created: {}".format(
len(block_rows)
)
)
message(
"Grid lines created: {}".format(
len(grid_rows)
)
)
message(
"Axes created: {}".format(
len(axes_rows)
)
)
message(
"Horizontal interval: {} feet.".format(
HORIZONTAL_INTERVAL_FT
)
)
message(
"Vertical interval: {} feet bgs.".format(
DEPTH_INTERVAL_FT
)
)
message(
"Vertical exaggeration: {}x.".format(
VERTICAL_EXAGGERATION
)
)
message(
"The existing dots and Report ID labels were not changed."
)
arcpy.ClearWorkspaceCache_management()
# =============================================================================
# SCRIPT ENTRY POINT
# =============================================================================
if __name__ == "__main__":
try:
main()
except Exception as error:
message(
"XS_A sticks, blocks, and axes failed: {}".format(
error
),
2
)
message(
traceback.format_exc(),
2
)
try:
arcgis_messages = (
arcpy.GetMessages(2)
)
if arcgis_messages:
message(
arcgis_messages,
2
)
except Exception:
pass
try:
arcpy.ClearWorkspaceCache_management()
except Exception:
pass
raise
Intervals:
