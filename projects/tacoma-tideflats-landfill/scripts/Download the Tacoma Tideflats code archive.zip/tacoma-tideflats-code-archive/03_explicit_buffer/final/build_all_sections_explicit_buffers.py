# -*- coding: utf-8 -*-
# NOTE: Extracted and normalized from Landfill Master Document.docx.
# Archive status: final available version for this category. Review configuration before execution.
# Public-safe copy: internal emails, user paths, and organization-specific locations were removed.

"""All-section build: preserve every selected source feature and use explicit XSEC-to-buffer mapping."""
import os
import re
import traceback
from datetime import datetime
import arcpy

# INPUTS - update these public-safe placeholder paths before execution
SECTION_LINE_FC = r"C:\path\to\project.gdb\Cross_SectionLines"
BUFFER_POLYGON_FC = r"C:\path\to\project.gdb\Cross_SectionLines_Buffer"
POINT_GDB = r"C:\path\to\investigation_data.gdb"
PORT_FC = os.path.join(POINT_GDB, "PortData")
NEIGHBORHOOD_FC = os.path.join(POINT_GDB, "NeighborhoodData")

SECTION_NAME_CANDIDATES = ["XSEC"]
PORT_ID_CANDIDATES = ["Report_ID", "REPORT_ID", "ReportID"]
PORT_CATEGORY_CANDIDATES = ["Landfill__Soil_Observation_Category",
                            "Landfill_Soil_Observation_Category", "Category"]
PORT_TOTAL_CANDIDATES = ["Depth_DEPTH", "TOTAL_DEPTH_FT", "Total_Depth_Ft"]
PORT_TOP_CANDIDATES = ["Depth_Orinigal_Interval_Top_ft_bgs",
                       "Depth_Original_Interval_Top_ft_bgs", "Depth_DEPTH_TOP"]
PORT_BOTTOM_CANDIDATES = ["Depth_Orinigal_Interval_Bottom_ft_bgs",
                          "Depth_Original_Interval_Bottom_ft_bgs", "Depth_DEPTH"]
PORT_GROUP_CANDIDATES = ["Depth_Contaminant_Group", "Contaminant_Groups",
                         "Contaminant_Group"]
PORT_EXCEED_CANDIDATES = ["Depth_Exceedance_Flag", "Exceedance_Flag"]
N_ID_CANDIDATES = ["FacilitySiteId", "FacilitySiteID", "Facility_Site_ID"]
N_CATEGORY_CANDIDATES = ["Contamination_Category", "ContaminationCategory", "Category"]

SECTION_BUFFER_OID = {
    "XS_A": 3,
    "XS_B": 1,
    "XS_C": 2,
    "XS_D": 4,
    "XS_E": 5,
}
MAP_PREFIX = "XSEC_"
OUTPUT_GDB_PREFIX = "XSEC_Outputs_Run"
VERTICAL_EXAGGERATION = 1.0
GROUND_ELEV_FT = 0.0
POINT_BAND_THICKNESS_FT = 0.5
BLOCK_HALF_WIDTH_FT = 5.0
MIN_DISPLAY_DEPTH_FT = 10.0
BOTTOM_PADDING_FT = 5.0
MAX_REASONABLE_DEPTH_FT = 300.0
HORIZONTAL_INTERVAL_FT = 100.0
DEPTH_INTERVAL_FT = 5.0
SAVE_PROJECT = True


def msg(text, severity=0):
    text = str(text)
    if severity == 2:
        arcpy.AddError(text)
    elif severity == 1:
        arcpy.AddWarning(text)
    else:
        arcpy.AddMessage(text)
    print(text)


def clean(value):
    if value is None:
        return ""
    value = str(value).strip()
    return "" if value.lower() in ("", "none", "null", "nan", "unknown") else value


def find_field(dataset, candidates, required=True):
    fields = arcpy.ListFields(dataset)
    expanded = []
    for candidate in candidates:
        expanded.extend([candidate, candidate + "_1"])
    for candidate in expanded:
        for field in fields:
            if field.name.lower() == candidate.lower():
                return field.name
    for candidate in expanded:
        for field in fields:
            if (field.aliasName or "").lower() == candidate.lower():
                return field.name
    if required:
        raise ValueError("None of {} found in {}. Fields: {}".format(
            candidates, dataset, [f.name for f in fields]))
    return None


def depth(value, allow_zero=False):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    minimum = 0.0 if allow_zero else 0.000001
    return value if minimum <= value <= MAX_REASONABLE_DEPTH_FT else None


def feet_factor(sr):
    unit = clean(sr.linearUnitName).lower()
    return 1.0 if "foot" in unit or "feet" in unit else 1.0 / 0.3048


def line_geom(coords):
    return arcpy.Polyline(arcpy.Array([arcpy.Point(float(x), float(y)) for x, y in coords]))


def polygon_geom(coords):
    return arcpy.Polygon(arcpy.Array([arcpy.Point(float(x), float(y)) for x, y in coords]))


def create_gdb(project):
    if not project.homeFolder:
        raise ValueError("Save the ArcGIS Pro project before running this script.")
    name = "{}_{}.gdb".format(OUTPUT_GDB_PREFIX, datetime.now().strftime("%Y%m%d_%H%M%S"))
    arcpy.management.CreateFileGDB(project.homeFolder, name)
    path = os.path.join(project.homeFolder, name)
    msg("Created test geodatabase: {}".format(path))
    return path


def create_fc(gdb, name, geometry_type, field_specs):
    path = os.path.join(gdb, name)
    arcpy.management.CreateFeatureclass(gdb, name, geometry_type)
    for name, field_type, length in field_specs:
        if field_type == "TEXT":
            arcpy.management.AddField(path, name, field_type, field_length=length)
        else:
            arcpy.management.AddField(path, name, field_type)
    return path


def write_rows(dataset, fields, rows):
    with arcpy.da.InsertCursor(dataset, fields) as cursor:
        for row in rows:
            cursor.insertRow(row)


def get_section_and_buffer(section_name):
    """Match each XSEC line to its explicitly associated buffer OID."""
    line_name_field = find_field(SECTION_LINE_FC, SECTION_NAME_CANDIDATES)
    line_oid_field = arcpy.Describe(SECTION_LINE_FC).OIDFieldName
    section_line = None
    with arcpy.da.SearchCursor(
        SECTION_LINE_FC, [line_oid_field, line_name_field, "SHAPE@"]
    ) as cursor:
        for line_oid, name, geometry in cursor:
            if clean(name).lower() == section_name.lower():
                section_line = geometry
                break
    if section_line is None:
        raise ValueError("Could not find {} in {}".format(section_name, SECTION_LINE_FC))

    wanted_buffer_oid = SECTION_BUFFER_OID[section_name]
    buffer_oid_field = arcpy.Describe(BUFFER_POLYGON_FC).OIDFieldName
    buffer_geometry = None
    with arcpy.da.SearchCursor(
        BUFFER_POLYGON_FC, [buffer_oid_field, "SHAPE@"]
    ) as cursor:
        for buffer_oid, geometry in cursor:
            if int(buffer_oid) == wanted_buffer_oid:
                buffer_geometry = geometry
                break
    if buffer_geometry is None:
        raise ValueError(
            "No buffer OID {} found for {}".format(wanted_buffer_oid, section_name)
        )
    msg("{} uses buffer OBJECTID {}".format(section_name, wanted_buffer_oid))
    return section_line, buffer_geometry


def inside(point_geometry, buffer_geometry):
    point = point_geometry.projectAs(buffer_geometry.spatialReference)
    if point.within(buffer_geometry) or buffer_geometry.contains(point):
        return True
    try:
        return buffer_geometry.distanceTo(point) == 0
    except Exception:
        return False


def station_source(dataset, section_line, buffer_geometry, label_field,
                   category_field=None, extras=None):
    """Keep every selected source feature and retain its true source OID."""
    extras = extras or {}
    oid_field = arcpy.Describe(dataset).OIDFieldName
    fields = ["SHAPE@", oid_field, label_field]
    if category_field:
        fields.append(category_field)
    valid_extras = [(key, field) for key, field in extras.items() if field]
    fields.extend(field for key, field in valid_extras)

    line_sr = section_line.spatialReference
    factor = feet_factor(line_sr)
    selected = []
    with arcpy.da.SearchCursor(dataset, fields) as cursor:
        for row in cursor:
            shape = row[0]
            if shape is None or not inside(shape, buffer_geometry):
                continue
            projected = shape.projectAs(line_sr)
            try:
                _, along, away, right = section_line.queryPointAndDistance(projected)
            except Exception:
                continue
            index = 3
            category = ""
            if category_field:
                category = clean(row[index])
                index += 1
            attrs = {}
            for key, field in valid_extras:
                attrs[key] = row[index]
                index += 1
            for key, field in extras.items():
                if not field:
                    attrs[key] = None
            away_ft = away * factor
            selected.append({
                "source_oid": int(row[1]),
                "label": clean(row[2]),
                "category": category or "Uncategorized",
                "station": along * factor,
                "distance": away_ft if right else -away_ft,
                "attrs": attrs,
            })
    return selected


def add_and_style(output_map, outputs):
    names = {os.path.basename(path) for path in outputs.values()}
    for layer in list(output_map.listLayers()):
        if layer.name in names:
            output_map.removeLayer(layer)
    order = ["grid", "axes", "surface", "bands", "sticks", "points", "anchors", "axlabels"]
    added = {}
    for key in reversed(order):
        added[key] = output_map.addDataFromPath(outputs[key])

    try:
        for key, field in (("points", "CATEGORY"), ("bands", "DISPLAY_CLASS")):
            sym = added[key].symbology
            sym.updateRenderer("UniqueValueRenderer")
            sym.renderer.fields = [field]
            added[key].symbology = sym
    except Exception as error:
        msg("Unique-value styling warning: {}".format(error), 1)

    for key in ("anchors", "axlabels"):
        try:
            sym = added[key].symbology
            sym.renderer.symbol.size = 0
            added[key].symbology = sym
            classes = added[key].listLabelClasses()
            if classes:
                classes[0].expression = "$feature.LABEL_TEXT"
            added[key].showLabels = True
        except Exception as error:
            msg("Label styling warning for {}: {}".format(key, error), 1)


def build_section(project, gdb, section_name):
    section_line, buffer_geometry = get_section_and_buffer(section_name)
    factor = feet_factor(section_line.spatialReference)
    length_ft = section_line.length * factor

    port_fields = {
        "id": find_field(PORT_FC, PORT_ID_CANDIDATES),
        "category": find_field(PORT_FC, PORT_CATEGORY_CANDIDATES, False),
        "total": find_field(PORT_FC, PORT_TOTAL_CANDIDATES, False),
        "top": find_field(PORT_FC, PORT_TOP_CANDIDATES, False),
        "bottom": find_field(PORT_FC, PORT_BOTTOM_CANDIDATES, False),
        "group": find_field(PORT_FC, PORT_GROUP_CANDIDATES, False),
        "exceed": find_field(PORT_FC, PORT_EXCEED_CANDIDATES, False),
    }
    neighborhood_fields = {
        "id": find_field(NEIGHBORHOOD_FC, N_ID_CANDIDATES),
        "category": find_field(NEIGHBORHOOD_FC, N_CATEGORY_CANDIDATES, False),
    }

    port = station_source(PORT_FC, section_line, buffer_geometry,
                          port_fields["id"], port_fields["category"],
                          {"total": port_fields["total"], "top": port_fields["top"],
                           "bottom": port_fields["bottom"], "group": port_fields["group"],
                           "exceed": port_fields["exceed"]})
    neighborhood = station_source(NEIGHBORHOOD_FC, section_line, buffer_geometry,
                                  neighborhood_fields["id"], neighborhood_fields["category"])

    msg("SECTION {} ({:.0f} ft)".format(section_name, length_ft))
    msg("  PortData source features inside buffer: {}".format(len(port)))
    msg("  NeighborhoodData source features inside buffer: {}".format(len(neighborhood)))
    msg("  Blank PortData IDs receiving OID labels: {}".format(sum(not r["label"] for r in port)))

    prepared = []
    max_depth = MIN_DISPLAY_DEPTH_FT
    for row in port:
        attrs = row["attrs"]
        total = depth(attrs.get("total"))
        top = depth(attrs.get("top"), True)
        bottom = depth(attrs.get("bottom"))
        candidates = [value for value in (total, bottom) if value is not None]
        total_depth = max(candidates) if candidates else None
        if bottom is not None:
            if top is None:
                top = max(0.0, bottom - POINT_BAND_THICKNESS_FT / 2.0)
                bottom += POINT_BAND_THICKNESS_FT / 2.0
            if top > bottom:
                top, bottom = bottom, top
        label = row["label"] or "PORT_OID_{}".format(row["source_oid"])
        prepared.append(dict(row, label=label, total_depth=total_depth, top=top,
                             bottom=bottom,
                             group=clean(attrs.get("group")) or "Unspecified",
                             exceed=clean(attrs.get("exceed")) or "Unknown"))
        if total_depth is not None:
            max_depth = max(max_depth, total_depth)
        if bottom is not None:
            max_depth = max(max_depth, bottom)

    ve = VERTICAL_EXAGGERATION
    max_depth = DEPTH_INTERVAL_FT * int(
        (max_depth + BOTTOM_PADDING_FT + DEPTH_INTERVAL_FT - 0.000001) / DEPTH_INTERVAL_FT)
    y_top = GROUND_ELEV_FT * ve
    y_bottom = (GROUND_ELEV_FT - max_depth) * ve
    scale = max(1.0, length_ft / 400.0)

    outputs = {
        "surface": create_fc(gdb, section_name + "_Surface_Line", "POLYLINE", [("FEATURE", "TEXT", 50)]),
        "points": create_fc(gdb, section_name + "_Points", "POINT", [
            ("SOURCE", "TEXT", 30), ("SOURCE_OID", "LONG", None),
            ("LABEL_ID", "TEXT", 150), ("CATEGORY", "TEXT", 150),
            ("STATION_FT", "DOUBLE", None), ("DEPTH_FT", "DOUBLE", None),
            ("DIST_FROM_LINE_FT", "DOUBLE", None), ("HAS_DEPTH", "SHORT", None)]),
        "sticks": create_fc(gdb, section_name + "_Depth_Sticks", "POLYLINE", [
            ("SOURCE_OID", "LONG", None), ("LABEL_ID", "TEXT", 150),
            ("DEPTH_FT", "DOUBLE", None), ("CATEGORY", "TEXT", 150)]),
        "bands": create_fc(gdb, section_name + "_Interval_Bands", "POLYGON", [
            ("SOURCE_OID", "LONG", None), ("LABEL_ID", "TEXT", 150),
            ("CATEGORY", "TEXT", 150), ("CONTAM_GROUP", "TEXT", 150),
            ("EXCEEDANCE", "TEXT", 60), ("TOP_FT", "DOUBLE", None),
            ("BOT_FT", "DOUBLE", None), ("DISPLAY_CLASS", "TEXT", 150)]),
        "anchors": create_fc(gdb, section_name + "_Label_Anchors", "POINT", [
            ("SOURCE", "TEXT", 30), ("SOURCE_OID", "LONG", None),
            ("LABEL_TEXT", "TEXT", 150), ("LABEL_ROLE", "TEXT", 30)]),
        "grid": create_fc(gdb, section_name + "_Grid", "POLYLINE", [("GRID_TYPE", "TEXT", 20)]),
        "axes": create_fc(gdb, section_name + "_Axes", "POLYLINE", [("AXIS", "TEXT", 20)]),
        "axlabels": create_fc(gdb, section_name + "_Axis_Labels", "POINT", [
            ("LABEL_TEXT", "TEXT", 150), ("LABEL_TYPE", "TEXT", 30)]),
    }

    write_rows(outputs["surface"], ["FEATURE", "SHAPE@"],
               [["Ground Surface (flat)", line_geom([(0, y_top), (length_ft, y_top)])]])

    points, sticks, bands, anchors = [], [], [], []
    for row in sorted(prepared, key=lambda item: (item["station"], item["source_oid"])):
        x = row["station"]
        has_depth = int(row["total_depth"] is not None)
        points.append(["PortData", row["source_oid"], row["label"], row["category"],
                       x, row["total_depth"], row["distance"], has_depth, (x, y_top)])
        anchors.append(["PortData", row["source_oid"], row["label"],
                        "PORT_DEPTH_ID" if has_depth else "PORT_SURFACE_ID",
                        (x, y_top + 2.0 * scale)])
        if has_depth:
            sticks.append([row["source_oid"], row["label"], row["total_depth"],
                           row["category"],
                           line_geom([(x, y_top),
                                      (x, (GROUND_ELEV_FT-row["total_depth"])*ve)])])
        if row["bottom"] is not None:
            top_y = (GROUND_ELEV_FT-row["top"])*ve
            bottom_y = (GROUND_ELEV_FT-row["bottom"])*ve
            ring = [(x-BLOCK_HALF_WIDTH_FT, top_y), (x+BLOCK_HALF_WIDTH_FT, top_y),
                    (x+BLOCK_HALF_WIDTH_FT, bottom_y), (x-BLOCK_HALF_WIDTH_FT, bottom_y),
                    (x-BLOCK_HALF_WIDTH_FT, top_y)]
            bands.append([row["source_oid"], row["label"], row["category"],
                          row["group"], row["exceed"], row["top"], row["bottom"],
                          row["category"], polygon_geom(ring)])

    for row in sorted(neighborhood, key=lambda item: (item["station"], item["source_oid"])):
        x = row["station"]
        label = row["label"] or "NEIGHBORHOOD_OID_{}".format(row["source_oid"])
        points.append(["NeighborhoodData", row["source_oid"], label, row["category"],
                       x, None, row["distance"], 0, (x, y_top)])
        anchors.append(["NeighborhoodData", row["source_oid"], label,
                        "NEIGHBORHOOD_ID", (x, y_top + 5.0 * scale)])

    write_rows(outputs["points"], ["SOURCE", "SOURCE_OID", "LABEL_ID", "CATEGORY",
               "STATION_FT", "DEPTH_FT", "DIST_FROM_LINE_FT", "HAS_DEPTH", "SHAPE@XY"], points)
    write_rows(outputs["sticks"], ["SOURCE_OID", "LABEL_ID", "DEPTH_FT", "CATEGORY", "SHAPE@"], sticks)
    write_rows(outputs["bands"], ["SOURCE_OID", "LABEL_ID", "CATEGORY", "CONTAM_GROUP",
               "EXCEEDANCE", "TOP_FT", "BOT_FT", "DISPLAY_CLASS", "SHAPE@"], bands)
    write_rows(outputs["anchors"], ["SOURCE", "SOURCE_OID", "LABEL_TEXT", "LABEL_ROLE", "SHAPE@XY"], anchors)

    grid, axes, labels = [], [], []
    station = 0.0
    while station <= length_ft + 0.01:
        grid.append(["STATION", line_geom([(station, y_top), (station, y_bottom)])])
        labels.append(["{:.0f}".format(station), "STATION", (station, y_bottom-1.5*scale)])
        station += HORIZONTAL_INTERVAL_FT
    depth_value = 0.0
    while depth_value <= max_depth + 0.01:
        y = (GROUND_ELEV_FT-depth_value)*ve
        grid.append(["DEPTH", line_geom([(0, y), (length_ft, y)])])
        labels.append(["{:.0f}".format(depth_value), "DEPTH", (-2.0*scale, y)])
        depth_value += DEPTH_INTERVAL_FT
    axes.extend([["BOTTOM", line_geom([(0, y_bottom), (length_ft, y_bottom)])],
                 ["LEFT", line_geom([(0, y_bottom), (0, y_top)])],
                 ["SURFACE", line_geom([(0, y_top), (length_ft, y_top)])]])
    labels.extend([["Distance Along Section (ft)", "TITLE_X",
                    (length_ft/2.0, y_bottom-4.0*scale)],
                   ["Depth Below Ground Surface (ft)", "TITLE_Y",
                    (-6.0*scale, (y_top+y_bottom)/2.0)]])
    write_rows(outputs["grid"], ["GRID_TYPE", "SHAPE@"], grid)
    write_rows(outputs["axes"], ["AXIS", "SHAPE@"], axes)
    write_rows(outputs["axlabels"], ["LABEL_TEXT", "LABEL_TYPE", "SHAPE@XY"], labels)

    output_map = project.listMaps(MAP_PREFIX + section_name)
    output_map = output_map[0] if output_map else project.createMap(MAP_PREFIX + section_name)
    add_and_style(output_map, outputs)

    msg("="*65)
    msg("{} COMPLETE".format(section_name))
    msg("PortData point features written: {}".format(len(port)))
    msg("Neighborhood point features written: {}".format(len(neighborhood)))
    msg("Total point features written: {}".format(len(points)))
    msg("Depth sticks written: {}".format(len(sticks)))
    msg("Interval bands written: {}".format(len(bands)))
    msg("Output: {}".format(gdb))
    msg("="*65)

    return len(points)


def main():
    arcpy.env.overwriteOutput = True
    for path in (SECTION_LINE_FC, BUFFER_POLYGON_FC, PORT_FC, NEIGHBORHOOD_FC):
        if not arcpy.Exists(path):
            raise ValueError("Missing dataset: {}".format(path))

    project = arcpy.mp.ArcGISProject("CURRENT")
    gdb = create_gdb(project)

    total_points = 0
    for section_name in ("XS_A", "XS_B", "XS_C", "XS_D", "XS_E"):
        total_points += build_section(project, gdb, section_name) or 0

    msg("=" * 65)
    msg("ALL SECTIONS COMPLETE")
    msg("Total point placements written: {}".format(total_points))
    msg("Output: {}".format(gdb))
    msg("=" * 65)

    if SAVE_PROJECT:
        try:
            project.save()
        except Exception as error:
            msg("Could not save project automatically: {}".format(error), 1)


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        msg("XS_A test failed: {}".format(error), 2)
        msg(traceback.format_exc(), 2)
        try:
            msg(arcpy.GetMessages(2), 2)
        except Exception:
            pass
        raise
