# Tacoma Tideflats ArcPy Code Archive

This archive was extracted from `Landfill Master Document.docx` and organized by workflow category.
Each Python file also has a matching Jupyter Notebook (`.ipynb`) for opening in an ArcGIS Pro notebook.

## Important

- The final version in each category is under a `final/` folder.
- Earlier versions are under `history/` to demonstrate development progression.
- Internal email content, user-specific Windows paths, and organization-specific locations were sanitized.
- The code was syntax-checked only. ArcPy execution requires ArcGIS Pro, the expected layers and fields, and project-specific configuration.
- Do not publish internal datasets, geodatabases, SharePoint links, or source documents without authorization.

## Categories

1. Depth-based concentric buffer rings
2. Multi-section cross-section automation, versions 01 through 08
3. All-section explicit-buffer workflow
4. XS_A Report ID labels and leader lines
5. XS_A depth sticks, status blocks, grid, and axes
6. XS_A contamination and cleanup interval blocks

## Syntax validation

- `01_depth_buffer_rings/final/create_depth_buffer_rings.py`: **PASS**
- `02_multisection_cross_sections/final/build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v01_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v02_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v03_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v04_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v05_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v06_build_cross_sections.py`: **PASS**
- `02_multisection_cross_sections/history/v07_build_cross_sections.py`: **PASS**
- `03_explicit_buffer/final/build_all_sections_explicit_buffers.py`: **PASS**
- `04_xs_a_labels/final/rebuild_labels_and_leaders.py`: **SOURCE_RECONSTRUCTION** - expected an indented block after function definition on line 83 at line 84
- `04_xs_a_labels/history/v01_rebuild_labels_and_leaders.py`: **SOURCE_RECONSTRUCTION** - expected an indented block after function definition on line 83 at line 84
- `05_xs_a_sticks_status/final/build_sticks_status_grid_axes.py`: **SOURCE_RECONSTRUCTION** - expected an indented block after function definition on line 134 at line 135
- `06_xs_a_interval_blocks/final/build_contamination_cleanup_intervals.py`: **SOURCE_RECONSTRUCTION** - expected an indented block after function definition on line 213 at line 214
