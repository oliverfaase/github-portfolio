# -*- coding: utf-8 -*-
# NOTE: Extracted and normalized from Landfill Master Document.docx.
# Archive status: historical workflow version. Review configuration before execution.
# Public-safe copy: internal emails, user paths, and organization-specific locations were removed.

"""
Rebuild XS_A Depth Report ID Anchors and Leader Lines Only
Run this entire block in one new ArcGIS Pro notebook cell.
Existing layer used
-------------------
PT_50 Location Dots - Status
Layers rebuilt
--------------
PT_51 Report ID Labels - With Depth
PT_52 Report ID Leader Lines
Behavior
--------
- Uses only locations where HAS_DEPTH = 1.
- Labels use REPORT_ID only, such as TP-4 or TP-80.
- The short leader line does not touch the 10-point location dot.
- The leader line stops before the Report ID label.
- The label anchor is completely transparent.
- No second visible dot is created at the label end.
- Existing feature classes are not deleted.
- Each run creates uniquely named feature classes when necessary.
- The existing location-dot layer is not recreated or changed.
"""
import os
import traceback
import arcpy
# =============================================================================
# SETTINGS
# =============================================================================
MAP_NAME = "XSEC_XS_A"
LOCATION_DOTS_LAYER_NAME = (
"PT_50 Location Dots - Status"
)
DEPTH_LABEL_LAYER_NAME = (
"PT_51 Report ID Labels - With Depth"
)
LEADER_LAYER_NAME = (
"PT_52 Report ID Leader Lines"
)
DEPTH_ANCHOR_FC_NAME = (
"XS_A_Depth_ReportID_Anchors"
)
LEADER_FC_NAME = (
"XS_A_ReportID_Leader_Lines"
)
SAVE_PROJECT_AT_END = True
# =============================================================================
# LEADER AND LABEL GEOMETRY
# =============================================================================
# These measurements are in cross-section feet.
#
# The leader begins away from the location dot.
# The label anchor is placed slightly beyond the leader endpoint.
#
# Appearance:
#
# location dot detached leader REPORT_ID
# ● ------- TP-4
LEADER_START_X_FT = 3.0
LEADER_START_Y_FT = 1.0
LEADER_END_X_FT = 8.0
LEADER_END_Y_FT = 3.0
LABEL_ANCHOR_X_FT = 9.5
LABEL_ANCHOR_Y_FT = 3.0
# =============================================================================
# DISPLAY SETTINGS
# =============================================================================
LEADER_LINE_COLOR = (
45,
45,
45,
100
)
LEADER_LINE_WIDTH_PT = 0.7
LABEL_TEXT_SIZE_PT = 9.0
# =============================================================================
# MESSAGE HELPER
# =============================================================================
def message(text, severity=0):
"""Write a message to ArcGIS Pro and the notebook."""
text = str(text)
if severity == 2:
arcpy.AddError(text)
elif severity == 1:
arcpy.AddWarning(text)
else:
arcpy.AddMessage(text)
print(text)
# =============================================================================
# GENERAL HELPERS
# =============================================================================
def clean_text(value):
"""Return clean text from a field value."""
if value is None:
return ""
text = str(value).strip()
if text.lower() in (
"",
"none",
"null",
"nan"
):
return ""
return text
def rgba(color):
"""Convert an RGBA tuple to an ArcGIS Pro color dictionary."""
return {
"RGB": list(color)
}
def find_map(project, map_name):
"""Find the requested map by its exact name."""
matching_maps = project.listMaps(
map_name
)
if not matching_maps:
raise ValueError(
"No map named '{}' was found.".format(
map_name
)
)
return matching_maps[0]
def find_layer(map_object, layer_name):
"""Find a layer by its exact displayed name."""
for layer in map_object.listLayers():
if (
layer.name.strip().lower()
== layer_name.strip().lower()
):
return layer
raise ValueError(
"No layer named '{}' was found in map '{}'.".format(
layer_name,
map_object.name
)
)
def find_field(
dataset,
candidates,
required=True
):
"""Return the first field matching one of the candidate names."""
fields = arcpy.ListFields(
dataset
)
# Exact field-name match.
for candidate in candidates:
for field in fields:
if (
field.name.lower()
== str(candidate).lower()
):
return field.name
# Exact field-alias match.
for candidate in candidates:
for field in fields:
if (
str(field.aliasName).lower()
== str(candidate).lower()
):
return field.name
if required:
raise ValueError(
"Could not find any of these fields: {}. "
"Available fields: {}.".format(
candidates,
[
field.name
for field in fields
]
)
)
return None
def determine_geodatabase(dataset_path):
"""
Walk upward from a feature-class path until its containing GDB is found.
This works whether the feature class is stored directly in the GDB or
inside a feature dataset.
"""
current_path = dataset_path
while current_path:
if current_path.lower().endswith(
".gdb"
):
return current_path
parent_path = os.path.dirname(
current_path
)
if (
not parent_path
or parent_path == current_path
):
break
current_path = parent_path
raise ValueError(
"Could not determine the file geodatabase containing: {}".format(
dataset_path
)
)
def remove_existing_map_layer(
map_object,
layer_name
):
"""
Remove an earlier displayed layer from the map.
This does not delete its underlying feature class.
"""
removed_count = 0
for layer in list(
map_object.listLayers()
):
if (
layer.name.strip().lower()
!= layer_name.strip().lower()
):
continue
try:
map_object.removeLayer(
layer
)
removed_count += 1
except Exception as error:
message(
"Could not remove old layer '{}': {}".format(
layer_name,
error
),
1
)
if removed_count > 0:
message(
"Removed {} old '{}' map layer(s).".format(
removed_count,
layer_name
)
)
def create_unique_feature_class_name(
output_workspace,
base_name
):
"""
Return a unique feature-class name and path.
Existing feature classes are not deleted. If the base name already
exists, the function tries _2, _3, and so on.
"""
validated_base_name = (
arcpy.ValidateTableName(
base_name,
output_workspace
)
)
output_name = validated_base_name
output_path = os.path.join(
output_workspace,
output_name
)
counter = 2
while arcpy.Exists(output_path):
output_name = (
arcpy.ValidateTableName(
"{}_{}".format(
validated_base_name,
counter
),
output_workspace
)
)
output_path = os.path.join(
output_workspace,
output_name
)
counter += 1
return output_name, output_path
# =============================================================================
# OUTPUT FEATURE CLASS CREATION
# =============================================================================
def create_anchor_feature_class(
output_workspace,
output_spatial_reference
):
"""
Create a new point feature class for invisible label anchors.
Existing feature classes are not deleted.
"""
(
output_name,
output_path
) = create_unique_feature_class_name(
output_workspace,
DEPTH_ANCHOR_FC_NAME
)
arcpy.management.CreateFeatureclass(
out_path=output_workspace,
out_name=output_name,
geometry_type="POINT",
spatial_reference=(
output_spatial_reference
)
)
arcpy.management.AddField(
in_table=output_path,
field_name="REPORT_ID",
field_type="TEXT",
field_length=100
)
arcpy.management.AddField(
in_table=output_path,
field_name="POINT_KEY",
field_type="TEXT",
field_length=255
)
arcpy.management.AddField(
in_table=output_path,
field_name="TOTAL_DEPTH_FT",
field_type="DOUBLE"
)
arcpy.management.AddField(
in_table=output_path,
field_name="LOCATION_STATUS",
field_type="TEXT",
field_length=30
)
message(
"Created depth-label anchor feature class:"
)
message(
output_path
)
return output_path
def create_leader_feature_class(
output_workspace,
output_spatial_reference
):
"""
Create a new polyline feature class for detached leader lines.
Existing feature classes are not deleted.
"""
(
output_name,
output_path
) = create_unique_feature_class_name(
output_workspace,
LEADER_FC_NAME
)
arcpy.management.CreateFeatureclass(
out_path=output_workspace,
out_name=output_name,
geometry_type="POLYLINE",
spatial_reference=(
output_spatial_reference
)
)
arcpy.management.AddField(
in_table=output_path,
field_name="REPORT_ID",
field_type="TEXT",
field_length=100
)
arcpy.management.AddField(
in_table=output_path,
field_name="POINT_KEY",
field_type="TEXT",
field_length=255
)
message(
"Created Report ID leader feature class:"
)
message(
output_path
)
return output_path
# =============================================================================
# READ EXISTING LOCATION DOTS
# =============================================================================
def field_value_is_depth(value):
"""Interpret the HAS_DEPTH field as a Boolean value."""
if value is None:
return False
if isinstance(value, (int, float)):
return int(value) == 1
value_text = clean_text(
value
).upper()
return value_text in (
"1",
"YES",
"Y",
"TRUE",
"WITH_DEPTH"
)
def build_depth_report_id_features(
location_dots_layer,
depth_anchor_fc,
report_leader_fc,
output_spatial_reference
):
"""
Build invisible Report ID anchors and detached lines from existing dots.
Only features where HAS_DEPTH equals 1 are used.
REPORT_ID is copied directly from the existing dot feature. OBJECTID,
POINT_KEY, or an automatic row number is never substituted as the label.
"""
location_dots_source = (
location_dots_layer.dataSource
)
report_id_field = find_field(
location_dots_source,
[
"REPORT_ID",
"ReportID",
"WELLID"
],
required=True
)
has_depth_field = find_field(
location_dots_source,
[
"HAS_DEPTH"
],
required=True
)
point_key_field = find_field(
location_dots_source,
[
"POINT_KEY"
],
required=False
)
total_depth_field = find_field(
location_dots_source,
[
"TOTAL_DEPTH_FT",
"DEPTH_FT"
],
required=False
)
location_status_field = find_field(
location_dots_source,
[
"LOCATION_STATUS",
"STATUS"
],
required=False
)
search_fields = [
report_id_field,
has_depth_field
]
point_key_index = None
total_depth_index = None
location_status_index = None
if point_key_field:
point_key_index = len(
search_fields
)
search_fields.append(
point_key_field
)
if total_depth_field:
total_depth_index = len(
search_fields
)
search_fields.append(
total_depth_field
)
if location_status_field:
location_status_index = len(
search_fields
)
search_fields.append(
location_status_field
)
shape_index = len(
search_fields
)
search_fields.append(
"SHAPE@"
)
anchor_rows = []
leader_rows = []
with arcpy.da.SearchCursor(
location_dots_source,
search_fields
) as cursor:
for row_number, row in enumerate(
cursor,
start=1
):
report_id = clean_text(
row[0]
)
has_depth = field_value_is_depth(
row[1]
)
# Only use points that have depth.
if not has_depth:
continue
if point_key_index is not None:
point_key = clean_text(
row[point_key_index]
)
else:
point_key = (
"DEPTH_LOCATION_{}".format(
row_number
)
)
if total_depth_index is not None:
total_depth = row[
total_depth_index
]
else:
total_depth = None
if location_status_index is not None:
location_status = clean_text(
row[
location_status_index
]
)
else:
location_status = ""
point_geometry = row[
shape_index
]
if point_geometry is None:
continue
source_point = (
point_geometry.firstPoint
)
if source_point is None:
continue
source_x = source_point.X
source_y = source_point.Y
# -------------------------------------------------------------
# Detached leader coordinates
# -------------------------------------------------------------
leader_start_x = (
source_x
+ LEADER_START_X_FT
)
leader_start_y = (
source_y
+ LEADER_START_Y_FT
)
leader_end_x = (
source_x
+ LEADER_END_X_FT
)
leader_end_y = (
source_y
+ LEADER_END_Y_FT
)
# -------------------------------------------------------------
# Invisible label-anchor coordinates
# -------------------------------------------------------------
label_anchor_x = (
source_x
+ LABEL_ANCHOR_X_FT
)
label_anchor_y = (
source_y
+ LABEL_ANCHOR_Y_FT
)
label_anchor_geometry = (
arcpy.PointGeometry(
arcpy.Point(
label_anchor_x,
label_anchor_y
),
output_spatial_reference
)
)
report_leader_geometry = (
arcpy.Polyline(
arcpy.Array([
arcpy.Point(
leader_start_x,
leader_start_y
),
arcpy.Point(
leader_end_x,
leader_end_y
)
]),
output_spatial_reference
)
)
anchor_rows.append([
report_id,
point_key,
total_depth,
location_status,
label_anchor_geometry
])
leader_rows.append([
report_id,
point_key,
report_leader_geometry
])
# -------------------------------------------------------------------------
# Write label-anchor features
# -------------------------------------------------------------------------
with arcpy.da.InsertCursor(
depth_anchor_fc,
[
"REPORT_ID",
"POINT_KEY",
"TOTAL_DEPTH_FT",
"LOCATION_STATUS",
"SHAPE@"
]
) as cursor:
for output_row in anchor_rows:
cursor.insertRow(
output_row
)
# -------------------------------------------------------------------------
# Write detached leader-line features
# -------------------------------------------------------------------------
with arcpy.da.InsertCursor(
report_leader_fc,
[
"REPORT_ID",
"POINT_KEY",
"SHAPE@"
]
) as cursor:
for output_row in leader_rows:
cursor.insertRow(
output_row
)
return (
len(anchor_rows),
len(leader_rows)
)
# =============================================================================
# LABEL AND SYMBOLOGY FUNCTIONS
# =============================================================================
def hide_anchor_symbols(layer):
"""
Make every label-anchor marker fully transparent.
The anchor feature remains available for labeling, but no endpoint dot
is displayed.
"""
try:
symbology = layer.symbology
symbol = symbology.renderer.symbol
symbol.color = rgba(
(
255,
255,
255,
0
)
)
if hasattr(
symbol,
"outlineColor"
):
symbol.outlineColor = rgba(
(
255,
255,
255,
0
)
)
if hasattr(
symbol,
"size"
):
symbol.size = 0.1
symbology.renderer.symbol = (
symbol
)
layer.symbology = symbology
except Exception as error:
message(
"Could not hide the label-anchor symbols: {}".format(
error
),
1
)
def enable_report_id_labels(layer):
"""
Label the invisible anchor features using REPORT_ID only.
Example labels:
TP-4
TP-80
MFG-1
"""
if not layer.supports(
"SHOWLABELS"
):
raise ValueError(
"The depth-anchor layer does not support labels."
)
layer.showLabels = True
label_classes = (
layer.listLabelClasses()
)
if not label_classes:
raise ValueError(
"The depth-anchor layer has no label class."
)
for label_class in label_classes:
label_class.expressionEngine = (
"Arcade"
)
# REPORT_ID is the only displayed label field.
label_class.expression = (
"IIf("
"IsEmpty($feature.REPORT_ID), "
"'', "
"$feature.REPORT_ID"
")"
)
label_class.visible = True
# Apply right-side placement and text size when supported.
try:
cim_label_class = (
label_class.getDefinition(
"V3"
)
)
placement = getattr(
cim_label_class,
"maplexLabelPlacementProperties",
None
)
if placement is not None:
if hasattr(
placement,
"pointPlacementMethod"
):
placement.pointPlacementMethod = (
"EastOfPoint"
)
if hasattr(
placement,
"primaryOffset"
):
placement.primaryOffset = 1.0
text_symbol_reference = getattr(
cim_label_class,
"textSymbol",
None
)
if text_symbol_reference is not None:
text_symbol = getattr(
text_symbol_reference,
"symbol",
None
)
if (
text_symbol is not None
and hasattr(
text_symbol,
"height"
)
):
text_symbol.height = (
LABEL_TEXT_SIZE_PT
)
label_class.setDefinition(
cim_label_class
)
except Exception as error:
message(
"Advanced label-formatting warning: {}".format(
error
),
1
)
def style_leader_lines(layer):
"""Style the short detached leader lines."""
try:
symbology = layer.symbology
symbol = symbology.renderer.symbol
symbol.color = rgba(
LEADER_LINE_COLOR
)
if hasattr(
symbol,
"size"
):
symbol.size = (
LEADER_LINE_WIDTH_PT
)
symbology.renderer.symbol = (
symbol
)
layer.symbology = symbology
except Exception as error:
message(
"Leader-line symbology warning: {}".format(
error
),
1
)
# =============================================================================
# MAIN
# =============================================================================
def main():
message(
"Rebuilding only the XS_A depth Report ID anchors and leader lines."
)
project = arcpy.mp.ArcGISProject(
"CURRENT"
)
map_object = find_map(
project,
MAP_NAME
)
location_dots_layer = find_layer(
map_object,
LOCATION_DOTS_LAYER_NAME
)
try:
if location_dots_layer.isBroken:
raise ValueError(
"The existing location-dot layer is broken."
)
except AttributeError:
pass
location_dots_source = (
location_dots_layer.dataSource
)
output_workspace = determine_geodatabase(
location_dots_source
)
output_spatial_reference = (
arcpy.Describe(
location_dots_source
).spatialReference
)
message(
"Existing location-dot source:"
)
message(
location_dots_source
)
message(
"New anchors and leaders will be written to:"
)
message(
output_workspace
)
# -------------------------------------------------------------------------
# Remove old displayed PT_51 and PT_52 layers
# -------------------------------------------------------------------------
remove_existing_map_layer(
map_object,
DEPTH_LABEL_LAYER_NAME
)
remove_existing_map_layer(
map_object,
LEADER_LAYER_NAME
)
arcpy.ClearWorkspaceCache_management()
# -------------------------------------------------------------------------
# Create new uniquely named outputs
# -------------------------------------------------------------------------
depth_anchor_fc = (
create_anchor_feature_class(
output_workspace,
output_spatial_reference
)
)
report_leader_fc = (
create_leader_feature_class(
output_workspace,
output_spatial_reference
)
)
# -------------------------------------------------------------------------
# Build anchors and leaders from the existing location dots
# -------------------------------------------------------------------------
(
anchor_count,
leader_count
) = build_depth_report_id_features(
location_dots_layer,
depth_anchor_fc,
report_leader_fc,
output_spatial_reference
)
if anchor_count == 0:
raise ValueError(
"No locations with HAS_DEPTH = 1 were found in "
"'{}'.".format(
LOCATION_DOTS_LAYER_NAME
)
)
if anchor_count != leader_count:
raise ValueError(
"Anchor count {} does not match leader count {}.".format(
anchor_count,
leader_count
)
)
# -------------------------------------------------------------------------
# Add the invisible anchor layer and enable Report ID labels
# -------------------------------------------------------------------------
depth_labels_layer = (
map_object.addDataFromPath(
depth_anchor_fc
)
)
depth_labels_layer.name = (
DEPTH_LABEL_LAYER_NAME
)
depth_labels_layer.visible = True
hide_anchor_symbols(
depth_labels_layer
)
enable_report_id_labels(
depth_labels_layer
)
# -------------------------------------------------------------------------
# Add and style the detached leader-line layer
# -------------------------------------------------------------------------
leader_layer = (
map_object.addDataFromPath(
report_leader_fc
)
)
leader_layer.name = (
LEADER_LAYER_NAME
)
leader_layer.visible = True
style_leader_lines(
leader_layer
)
# -------------------------------------------------------------------------
# Verify output feature counts
# -------------------------------------------------------------------------
written_anchor_count = int(
arcpy.management.GetCount(
depth_anchor_fc
)[0]
)
written_leader_count = int(
arcpy.management.GetCount(
report_leader_fc
)[0]
)
if written_anchor_count != anchor_count:
raise ValueError(
"Expected {} anchors, but {} were written.".format(
anchor_count,
written_anchor_count
)
)
if written_leader_count != leader_count:
raise ValueError(
"Expected {} leader lines, but {} were written.".format(
leader_count,
written_leader_count
)
)
# -------------------------------------------------------------------------
# Save and report
# -------------------------------------------------------------------------
if SAVE_PROJECT_AT_END:
project.save()
message("")
message("=" * 72)
message("DEPTH REPORT ID ANCHORS REBUILT")
message("=" * 72)
message(
"Report ID labels created: {}".format(
written_anchor_count
)
)
message(
"Detached leader lines created: {}".format(
written_leader_count
)
)
message(
"Label field: REPORT_ID"
)
message(
"Anchor symbols are transparent, so no second endpoint dot appears."
)
message(
"The leader lines begin away from the existing location dots."
)
message(
"The existing location dots were not recreated or modified."
)
message(
"Anchor feature class: {}".format(
depth_anchor_fc
)
)
message(
"Leader feature class: {}".format(
report_leader_fc
)
)
message(
"Displayed label layer: {}".format(
DEPTH_LABEL_LAYER_NAME
)
)
message(
"Displayed leader layer: {}".format(
LEADER_LAYER_NAME
)
)
arcpy.ClearWorkspaceCache_management()
# =============================================================================
# SCRIPT ENTRY POINT
# =============================================================================
if __name__ == "__main__":
try:
main()
except Exception as error:
message(
"Depth Report ID rebuild failed: {}".format(
error
),
2
)
message(
traceback.format_exc(),
2
)
try:
arcgis_messages = (
arcpy.GetMessages(2)
)
if arcgis_messages:
message(
arcgis_messages,
2
)
except Exception:
pass
try:
arcpy.ClearWorkspaceCache_management()
except Exception:
pass
raise
Specific Labeling for Depths (with lines):
