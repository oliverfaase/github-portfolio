# Reconstruction notice

This category was preserved from the Word archive, but the Word export removed Python indentation from parts of the script. The `.py` and `.ipynb` files preserve the documented workflow and ordering, but they must be compared with the original ArcGIS Pro notebook before execution. They are included to show development history and should not be presented as tested production code.
