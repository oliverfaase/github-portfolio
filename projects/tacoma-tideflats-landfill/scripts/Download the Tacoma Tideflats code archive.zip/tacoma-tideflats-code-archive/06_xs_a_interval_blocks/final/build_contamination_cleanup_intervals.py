# -*- coding: utf-8 -*-
# NOTE: Extracted and normalized from Landfill Master Document.docx.
# Archive status: final available version for this category. Review configuration before execution.
# Public-safe copy: internal emails, user paths, and organization-specific locations were removed.

"""
Rebuild only XS_A contamination and cleanup interval blocks.
Required existing items
-----------------------
Map:
XSEC_XS_A
Existing location-dot layer:
PT_50 Location Dots - Status
Joined source layer:
ContaminationPoints2
Output
------
PT_41 Contamination and Cleanup Intervals
Behavior
--------
- Does not modify the location dots.
- Does not modify the Report ID labels.
- Does not modify the sticks, axes, or grid.
- Creates blocks only at documented depth intervals.
- Uses actual interval top and bottom depths.
- Converts a result at one depth into a narrow 0.5-foot display band.
- Does not automatically extend blocks through the full stick depth.
- Adds contamination, cleanup, exceedance, and MTCA attributes.
- Uses DISPLAY_CLASS as the default symbology field.
- Allows symbology to be changed to other output fields.
- Creates a uniquely named feature class on each run.
"""
import os
import re
import traceback
import arcpy
arcpy.env.overwriteOutput = False
# =============================================================================
# INPUT AND OUTPUT SETTINGS
# =============================================================================
MAP_NAME = "XSEC_XS_A"
DOTS_LAYER_NAME = (
"PT_50 Location Dots - Status"
)
JOINED_LAYER_NAME = (
"ContaminationPoints2"
)
OUTPUT_LAYER_NAME = (
"PT_41 Contamination and Cleanup Intervals"
)
OUTPUT_FC_BASE = (
"XS_A_Contamination_Cleanup_Intervals"
)
SAVE_PROJECT = True
# =============================================================================
# CROSS-SECTION DISPLAY SETTINGS
# =============================================================================
VERTICAL_EXAGGERATION = 5.0
# A value of 5 creates a 10-foot-wide block.
BLOCK_HALF_WIDTH_FT = 5.0
# Point-depth results are shown as 0.5-foot-thick bands.
POINT_BAND_THICKNESS_FT = 0.5
MAX_DEPTH_FT = 300.0
# =============================================================================
# DEFAULT DISPLAY COLORS
# =============================================================================
CLASS_COLORS = {
"EXCEEDS": (
220,
40,
40,
70
),
"CLEANED_UP": (
52,
168,
83,
65
),
"BELOW_CLEANUP": (
85,
190,
115,
65
),
"CONTAMINATION": (
230,
126,
34,
65
),
"NO_DATA": (
150,
150,
150,
45
),
"UNKNOWN": (
190,
190,
190,
45
)
}
# =============================================================================
# SOURCE FIELD CANDIDATES
# =============================================================================
FIELD_CANDIDATES = {
"source_report_id": [
"WELLID",
"ReportID",
"ReportID_1"
],
"analytical_report_id": [
"Depth_ReportID",
"Depth_ReportID_1"
],
"parcel": [
"Parcel",
"Parcel_1",
"Depth_Parcel_ID"
],
"project": [
"Project",
"Project_1"
],
"location_type": [
"Type",
"Type_1"
],
"interval_top": [
"Depth_Original_Interval_Top_ft_bgs",
"Depth_Original_Interval_Top_ft_bgs_1",
"Depth_DEPTH_TOP",
"Original_Interval_Top_ft_bgs",
"DEPTH_TOP"
],
"interval_bottom": [
"Depth_Original_Interval_Bottom_ft_bgs",
"Depth_Original_Interval_Bottom_ft_bgs_1",
"Depth_DEPTH",
"Original_Interval_Bottom_ft_bgs",
"DEPTH"
],
"contaminants": [
"Contaminants",
"Contaminants_1"
],
"contaminant_group": [
"Depth_Contaminant_Group",
"Contaminant_Groups",
"Contaminants_1",
"Contaminants"
],
"status": [
"Status",
"Status_1"
],
"cleanup": [
"Cleanup",
"Cleanup_1"
],
"category": [
"Category",
"Category_1"
],
"notes": [
"Notes",
"Notes_1"
],
"analytical_status": [
"Depth_Analytical_Status_Simple",
"Analytical_Status_Simple"
],
"exceedance_flag": [
"Depth_Exceedance_Flag",
"Exceedance_Flag"
],
"depth_match": [
"Depth_Match_Status"
],
"result_details": [
"Depth_Specific_Analytes_or_Result_Details",
"Specific_Analytes_or_Result_Details",
"Levels"
],
"source_document": [
"Depth_Source_Document",
"SourceDoc",
"SourceDoc_1",
"Source_Document"
],
"mtca_soil": [
"MTCA_Soil_Exceedance",
"Depth_MTCA_Soil_Exceedance"
],
"mtca_gw": [
"MTCA_Groundwater_Exceedance",
"Depth_MTCA_Groundwater_Exceedance"
],
"mtca_sw": [
"MTCA_Surface_Water_Exceedance",
"Depth_MTCA_Surface_Water_Exceedance"
],
"mtca_sed": [
"MTCA_Sediment_Exceedance",
"Depth_MTCA_Sediment_Exceedance"
]
}
# =============================================================================
# GENERAL HELPERS
# =============================================================================
def message(text, severity=0):
"""Write a message to ArcGIS Pro and the notebook."""
text = str(text)
if severity == 2:
arcpy.AddError(text)
elif severity == 1:
arcpy.AddWarning(text)
else:
arcpy.AddMessage(text)
print(text)
def clean(value):
"""Return clean text from a field value."""
if value is None:
return ""
text = str(value).strip()
if text.lower() in (
"",
"none",
"null",
"nan"
):
return ""
return text
def normalize_name(value):
"""Normalize a field name for matching."""
return re.sub(
r"[^a-z0-9]+",
"",
clean(value).lower()
)
def report_key(value):
"""Normalize a Report ID for matching."""
return re.sub(
r"\s+",
"",
clean(value).upper()
)
def rgba(color):
"""Convert an RGBA tuple to an ArcGIS color dictionary."""
return {
"RGB": list(color)
}
def truncate_text(
value,
maximum_length
):
"""Trim text so it fits within an output field."""
text = clean(value)
if len(text) <= maximum_length:
return text
return (
text[:maximum_length - 3]
+ "..."
)
def numeric_depth(value):
"""Extract a reasonable numeric depth."""
if value is None:
return None
if isinstance(value, (int, float)):
depth = float(value)
if (
depth >= 0
and depth <= MAX_DEPTH_FT
):
return depth
return None
number_strings = re.findall(
r"-?\d+(?:\.\d+)?",
clean(value).replace(",", "")
)
depths = []
for number_string in number_strings:
depth = float(number_string)
if (
depth >= 0
and depth <= MAX_DEPTH_FT
):
depths.append(depth)
if not depths:
return None
return max(depths)
# =============================================================================
# MAP AND LAYER HELPERS
# =============================================================================
def find_map(project, name):
"""Find a map by its exact name."""
matching_maps = project.listMaps(
name
)
if not matching_maps:
raise ValueError(
"Map '{}' was not found.".format(
name
)
)
return matching_maps[0]
def find_layer(
map_object,
name
):
"""Find a layer by its exact displayed name."""
for layer in map_object.listLayers():
if (
layer.name.strip().lower()
== name.strip().lower()
):
return layer
raise ValueError(
"Layer '{}' was not found in map '{}'.".format(
name,
map_object.name
)
)
def find_joined_layer(project):
"""Find ContaminationPoints2 anywhere in the current project."""
for map_object in project.listMaps():
for layer in map_object.listLayers():
if not layer.isFeatureLayer:
continue
if (
layer.name.strip().lower()
!= JOINED_LAYER_NAME.lower()
):
continue
try:
if layer.isBroken:
continue
except Exception:
pass
return layer
raise ValueError(
"Layer '{}' was not found.".format(
JOINED_LAYER_NAME
)
)
def resolve_field(
dataset,
candidates,
required=False
):
"""Resolve a field by name, alias, normalized name, or suffix."""
fields = arcpy.ListFields(
dataset
)
# Exact name or alias.
for candidate in candidates:
for field in fields:
if (
field.name.lower()
== candidate.lower()
):
return field.name
if (
str(field.aliasName).lower()
== candidate.lower()
):
return field.name
# Normalized exact match.
for candidate in candidates:
target = normalize_name(
candidate
)
for field in fields:
possible_names = [
field.name,
getattr(
field,
"baseName",
""
),
field.aliasName
]
if any(
normalize_name(name) == target
for name in possible_names
):
return field.name
# Normalized suffix match.
for candidate in candidates:
target = normalize_name(
candidate
)
for field in fields:
possible_names = [
field.name,
getattr(
field,
"baseName",
""
),
field.aliasName
]
if any(
normalize_name(name).endswith(
target
)
for name in possible_names
):
return field.name
if required:
raise ValueError(
"Missing required field {}. Available fields: {}.".format(
candidates,
[
field.name
for field in fields
]
)
)
return None
def get_geodatabase(dataset_path):
"""Find the geodatabase containing a dataset."""
current_path = dataset_path
while current_path:
if current_path.lower().endswith(
".gdb"
):
return current_path
parent_path = os.path.dirname(
current_path
)
if (
not parent_path
or parent_path == current_path
):
break
current_path = parent_path
raise ValueError(
"Could not determine the geodatabase for: {}".format(
dataset_path
)
)
def unique_output(
workspace,
base_name
):
"""Create a unique feature-class name and path."""
validated_base_name = (
arcpy.ValidateTableName(
base_name,
workspace
)
)
output_name = validated_base_name
output_path = os.path.join(
workspace,
output_name
)
counter = 2
while arcpy.Exists(output_path):
output_name = (
arcpy.ValidateTableName(
"{}_{}".format(
validated_base_name,
counter
),
workspace
)
)
output_path = os.path.join(
workspace,
output_name
)
counter += 1
return output_name, output_path
# =============================================================================
# EXPORT JOINED SOURCE
# =============================================================================
def export_joined(
joined_layer,
scratch_geodatabase
):
"""Export the joined layer so joined fields become ordinary fields."""
try:
arcpy.management.SelectLayerByAttribute(
joined_layer,
"CLEAR_SELECTION"
)
except Exception:
pass
(
output_name,
output_path
) = unique_output(
scratch_geodatabase,
"XS_A_Interval_Source"
)
arcpy.conversion.ExportFeatures(
in_features=joined_layer,
out_features=output_path
)
row_count = int(
arcpy.management.GetCount(
output_path
)[0]
)
if row_count == 0:
raise ValueError(
"The joined source export contains zero rows."
)
message(
"Exported {} joined source rows.".format(
row_count
)
)
return output_path
# =============================================================================
# READ JOINED SOURCE RECORDS
# =============================================================================
def read_source_records(joined_export):
"""Read contamination and interval records from the joined export."""
resolved_fields = {}
for (
logical_name,
candidates
) in FIELD_CANDIDATES.items():
resolved_fields[
logical_name
] = resolve_field(
joined_export,
candidates,
required=(
logical_name
== "source_report_id"
)
)
message(
"Resolved interval fields:"
)
for (
logical_name,
field_name
) in resolved_fields.items():
message(
" {}: {}".format(
logical_name,
field_name
)
)
read_keys = [
key
for key, field_name
in resolved_fields.items()
if field_name
]
read_fields = [
resolved_fields[key]
for key in read_keys
]
records_by_report_id = {}
with arcpy.da.SearchCursor(
joined_export,
read_fields
) as cursor:
for row in cursor:
record = dict(
zip(
read_keys,
row
)
)
report_id = (
clean(
record.get(
"source_report_id"
)
)
or clean(
record.get(
"analytical_report_id"
)
)
)
key = report_key(
report_id
)
if not key:
continue
record[
"report_id"
] = report_id
records_by_report_id.setdefault(
key,
[]
).append(record)
return records_by_report_id
# =============================================================================
# READ EXISTING XS_A LOCATIONS
# =============================================================================
def read_xs_a_locations(dots_layer):
"""Read Report IDs and station positions from the existing dots."""
data_source = (
dots_layer.dataSource
)
report_id_field = resolve_field(
data_source,
[
"REPORT_ID",
"ReportID",
"WELLID"
],
required=True
)
station_field = resolve_field(
data_source,
[
"STATION_FT"
]
)
point_key_field = resolve_field(
data_source,
[
"POINT_KEY"
]
)
search_fields = [
report_id_field
]
station_index = None
point_key_index = None
if station_field:
station_index = len(
search_fields
)
search_fields.append(
station_field
)
if point_key_field:
point_key_index = len(
search_fields
)
search_fields.append(
point_key_field
)
shape_index = len(
search_fields
)
search_fields.append(
"SHAPE@"
)
locations = []
with arcpy.da.SearchCursor(
data_source,
search_fields
) as cursor:
for row_number, row in enumerate(
cursor,
start=1
):
report_id = clean(
row[0]
)
normalized_report = report_key(
report_id
)
geometry = row[
shape_index
]
if (
not normalized_report
or geometry is None
or geometry.firstPoint is None
):
continue
if station_index is not None:
try:
station = float(
row[station_index]
)
except Exception:
station = (
geometry.firstPoint.X
)
else:
station = (
geometry.firstPoint.X
)
if point_key_index is not None:
point_key = clean(
row[point_key_index]
)
else:
point_key = (
"XS_A_POINT_{}".format(
row_number
)
)
locations.append({
"report_id": report_id,
"report_key": normalized_report,
"point_key": point_key,
"station": station
})
return locations
# =============================================================================
# INTERVAL CLASSIFICATION
# =============================================================================
def classify_interval(record):
"""Classify one documented contamination or cleanup interval."""
mtca_fields = (
"mtca_soil",
"mtca_gw",
"mtca_sw",
"mtca_sed"
)
for field_name in mtca_fields:
value = clean(
record.get(field_name)
).upper()
if value in (
"YES",
"Y",
"TRUE",
"1"
):
return "EXCEEDS"
status_text = " | ".join(
clean(record.get(field_name))
for field_name in (
"status",
"cleanup",
"category",
"notes",
"analytical_status",
"exceedance_flag"
)
).upper()
if any(
term in status_text
for term in (
"CONFIRMED EXCEEDANCE",
"ABOVE MTCA",
"ABOVE CLEANUP",
"EXCEEDANCE"
)
):
return "EXCEEDS"
if any(
term in status_text
for term in (
"DETECTED BELOW CLEANUP",
"BELOW CLEANUP",
"NOT DETECT",
"NON-DETECT"
)
):
return "BELOW_CLEANUP"
if any(
term in status_text
for term in (
"CONFIRMED CLEAN OR CLEANED UP",
"CLEANED UP",
"REMEDIAT",
"WITHIN CLEANUP FOOTPRINT"
)
):
return "CLEANED_UP"
contamination_text = " | ".join(
clean(record.get(field_name))
for field_name in (
"contaminants",
"contaminant_group",
"result_details",
"exceedance_flag"
)
).upper()
if any(
term in contamination_text
for term in (
"DETECTED",
"PETROLEUM",
"METAL",
"VOC",
"PAH",
"PCB",
"PFAS",
"PESTICIDE",
"ORGANIC",
"LANDFILL",
"REFUSE"
)
):
return "CONTAMINATION"
if any(
term in status_text
for term in (
"NO DATA",
"NO ANALYTICAL DATA",
"DATA GAP"
)
):
return "NO_DATA"
return "UNKNOWN"
# =============================================================================
# INTERVAL GEOMETRY
# =============================================================================
def make_interval_polygon(
station,
top_depth,
bottom_depth,
spatial_reference
):
"""Create one depth-specific cross-section polygon."""
top_y = (
-top_depth
* VERTICAL_EXAGGERATION
)
bottom_y = (
-bottom_depth
* VERTICAL_EXAGGERATION
)
points = arcpy.Array([
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
bottom_y
),
arcpy.Point(
station + BLOCK_HALF_WIDTH_FT,
bottom_y
),
arcpy.Point(
station + BLOCK_HALF_WIDTH_FT,
top_y
),
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
top_y
),
arcpy.Point(
station - BLOCK_HALF_WIDTH_FT,
bottom_y
)
])
return arcpy.Polygon(
points,
spatial_reference
)
# =============================================================================
# BUILD INTERVAL ROWS
# =============================================================================
def build_interval_rows(
locations,
source_records,
spatial_reference
):
"""Build depth-specific contamination and cleanup polygons."""
rows = []
seen_rows = set()
for location in locations:
matching_records = (
source_records.get(
location["report_key"],
[]
)
)
for record in matching_records:
top_depth = numeric_depth(
record.get(
"interval_top"
)
)
bottom_depth = numeric_depth(
record.get(
"interval_bottom"
)
)
# Do not create whole-depth blocks when no interval is known.
if (
top_depth is None
and bottom_depth is None
):
continue
if top_depth is None:
top_depth = bottom_depth
if bottom_depth is None:
bottom_depth = top_depth
interval_top = min(
top_depth,
bottom_depth
)
interval_bottom = max(
top_depth,
bottom_depth
)
# A result at one depth becomes a narrow display band.
if interval_top == interval_bottom:
half_thickness = (
POINT_BAND_THICKNESS_FT
/ 2.0
)
interval_top = max(
0.0,
interval_top
- half_thickness
)
interval_bottom = (
interval_bottom
+ half_thickness
)
display_class = (
classify_interval(
record
)
)
contaminant_group = (
clean(
record.get(
"contaminant_group"
)
)
or "No Data"
)
duplicate_key = (
location["point_key"],
round(
interval_top,
3
),
round(
interval_bottom,
3
),
display_class,
contaminant_group.upper(),
clean(
record.get(
"exceedance_flag"
)
).upper()
)
if duplicate_key in seen_rows:
continue
seen_rows.add(
duplicate_key
)
interval_geometry = (
make_interval_polygon(
location["station"],
interval_top,
interval_bottom,
spatial_reference
)
)
rows.append([
"XS_A",
location["point_key"],
location["report_id"],
location["station"],
interval_top,
interval_bottom,
display_class,
truncate_text(
contaminant_group,
500
),
truncate_text(
record.get(
"contaminants"
),
1000
),
truncate_text(
record.get("status"),
500
),
truncate_text(
record.get("cleanup"),
500
),
truncate_text(
record.get("category"),
500
),
truncate_text(
record.get(
"analytical_status"
),
500
),
truncate_text(
record.get(
"exceedance_flag"
),
500
),
truncate_text(
record.get(
"depth_match"
),
500
),
truncate_text(
record.get(
"result_details"
),
1500
),
truncate_text(
record.get(
"source_document"
),
1000
),
truncate_text(
record.get("mtca_soil"),
150
),
truncate_text(
record.get("mtca_gw"),
150
),
truncate_text(
record.get("mtca_sw"),
150
),
truncate_text(
record.get("mtca_sed"),
150
),
truncate_text(
record.get("project"),
500
),
truncate_text(
record.get(
"location_type"
),
100
),
truncate_text(
record.get("parcel"),
100
),
truncate_text(
record.get("notes"),
1500
),
interval_geometry
])
return rows
# =============================================================================
# CREATE OUTPUT FEATURE CLASS
# =============================================================================
def create_output(
workspace,
spatial_reference
):
"""Create the contamination and cleanup interval feature class."""
(
output_name,
output_path
) = unique_output(
workspace,
OUTPUT_FC_BASE
)
arcpy.management.CreateFeatureclass(
out_path=workspace,
out_name=output_name,
geometry_type="POLYGON",
spatial_reference=spatial_reference
)
output_fields = [
(
"XSEC",
"TEXT",
40
),
(
"POINT_KEY",
"TEXT",
255
),
(
"REPORT_ID",
"TEXT",
100
),
(
"STATION_FT",
"DOUBLE",
None
),
(
"TOP_FT",
"DOUBLE",
None
),
(
"BOTTOM_FT",
"DOUBLE",
None
),
(
"DISPLAY_CLASS",
"TEXT",
40
),
(
"CONTAM_GROUP",
"TEXT",
500
),
(
"CONTAMINANTS",
"TEXT",
1000
),
(
"SOURCE_STATUS",
"TEXT",
500
),
(
"CLEANUP",
"TEXT",
500
),
(
"CATEGORY",
"TEXT",
500
),
(
"ANALYTICAL_STATUS",
"TEXT",
500
),
(
"EXCEEDANCE_FLAG",
"TEXT",
500
),
(
"DEPTH_MATCH",
"TEXT",
500
),
(
"RESULT_DETAILS",
"TEXT",
1500
),
(
"SOURCE_DOCUMENT",
"TEXT",
1000
),
(
"MTCA_SOIL",
"TEXT",
150
),
(
"MTCA_GW",
"TEXT",
150
),
(
"MTCA_SW",
"TEXT",
150
),
(
"MTCA_SEDIMENT",
"TEXT",
150
),
(
"PROJECT",
"TEXT",
500
),
(
"LOCATION_TYPE",
"TEXT",
100
),
(
"PARCEL",
"TEXT",
100
),
(
"NOTES",
"TEXT",
1500
)
]
for (
field_name,
field_type,
field_length
) in output_fields:
parameters = {}
if field_type == "TEXT":
parameters[
"field_length"
] = field_length
arcpy.management.AddField(
in_table=output_path,
field_name=field_name,
field_type=field_type,
**parameters
)
message(
"Created interval feature class:"
)
message(
output_path
)
return output_path
# =============================================================================
# WRITE OUTPUT ROWS
# =============================================================================
def write_rows(
output_feature_class,
rows
):
"""Write the interval polygons and attributes."""
insert_fields = [
"XSEC",
"POINT_KEY",
"REPORT_ID",
"STATION_FT",
"TOP_FT",
"BOTTOM_FT",
"DISPLAY_CLASS",
"CONTAM_GROUP",
"CONTAMINANTS",
"SOURCE_STATUS",
"CLEANUP",
"CATEGORY",
"ANALYTICAL_STATUS",
"EXCEEDANCE_FLAG",
"DEPTH_MATCH",
"RESULT_DETAILS",
"SOURCE_DOCUMENT",
"MTCA_SOIL",
"MTCA_GW",
"MTCA_SW",
"MTCA_SEDIMENT",
"PROJECT",
"LOCATION_TYPE",
"PARCEL",
"NOTES",
"SHAPE@"
]
with arcpy.da.InsertCursor(
output_feature_class,
insert_fields
) as cursor:
for row in rows:
cursor.insertRow(row)
# =============================================================================
# SYMBOLOGY
# =============================================================================
def style_layer(layer):
"""Apply default unique-value symbology using DISPLAY_CLASS."""
try:
symbology = layer.symbology
symbology.updateRenderer(
"UniqueValueRenderer"
)
symbology.renderer.fields = [
"DISPLAY_CLASS"
]
layer.symbology = symbology
symbology = layer.symbology
for renderer_group in (
symbology.renderer.groups
):
for item in renderer_group.items:
class_value = str(
item.values[0][0]
)
item.symbol.color = rgba(
CLASS_COLORS.get(
class_value,
CLASS_COLORS["UNKNOWN"]
)
)
if hasattr(
item.symbol,
"outlineColor"
):
item.symbol.outlineColor = (
rgba(
(
55,
55,
55,
75
)
)
)
if class_value == "EXCEEDS":
item.label = "Exceeds"
elif class_value == "CLEANED_UP":
item.label = "Cleaned Up"
elif class_value == "BELOW_CLEANUP":
item.label = (
"Detected Below Cleanup"
)
elif class_value == "CONTAMINATION":
item.label = (
"Contamination or Detection"
)
elif class_value == "NO_DATA":
item.label = "No Data"
elif class_value == "UNKNOWN":
item.label = "Unknown"
layer.symbology = symbology
except Exception as error:
message(
"Symbology warning: {}".format(
error
),
1
)
def replace_display_layer(
map_object,
output_feature_class
):
"""Replace only the displayed interval layer."""
for layer in list(
map_object.listLayers()
):
if (
layer.name.strip().lower()
== OUTPUT_LAYER_NAME.lower()
):
map_object.removeLayer(
layer
)
interval_layer = (
map_object.addDataFromPath(
output_feature_class
)
)
interval_layer.name = (
OUTPUT_LAYER_NAME
)
interval_layer.visible = True
style_layer(
interval_layer
)
# =============================================================================
# MAIN
# =============================================================================
def main():
message(
"Rebuilding XS_A contamination and cleanup interval blocks."
)
project = arcpy.mp.ArcGISProject(
"CURRENT"
)
map_object = find_map(
project,
MAP_NAME
)
dots_layer = find_layer(
map_object,
DOTS_LAYER_NAME
)
joined_layer = find_joined_layer(
project
)
dots_source = (
dots_layer.dataSource
)
output_workspace = (
get_geodatabase(
dots_source
)
)
spatial_reference = (
arcpy.Describe(
dots_source
).spatialReference
)
message(
"Using XS_A location dots:"
)
message(
dots_source
)
message(
"Writing interval polygons to:"
)
message(
output_workspace
)
# Flatten the joined source fields.
joined_export = export_joined(
joined_layer,
project.defaultGeodatabase
)
# Read analytical records by Report ID.
source_records = (
read_source_records(
joined_export
)
)
# Read XS_A point positions from the existing dot layer.
locations = read_xs_a_locations(
dots_layer
)
if not locations:
raise ValueError(
"No valid Report IDs were found in the XS_A location dots."
)
message(
"XS_A locations read: {}".format(
len(locations)
)
)
# Build actual depth-specific polygons.
interval_rows = build_interval_rows(
locations,
source_records,
spatial_reference
)
if not interval_rows:
raise ValueError(
"No documented depth intervals matched the XS_A dots."
)
message(
"Interval polygons prepared: {}".format(
len(interval_rows)
)
)
# Create and populate the output.
output_feature_class = (
create_output(
output_workspace,
spatial_reference
)
)
write_rows(
output_feature_class,
interval_rows
)
written_count = int(
arcpy.management.GetCount(
output_feature_class
)[0]
)
if written_count != len(
interval_rows
):
raise ValueError(
"Prepared {} intervals, but {} were written.".format(
len(interval_rows),
written_count
)
)
# Replace only PT_41 in the map.
replace_display_layer(
map_object,
output_feature_class
)
if SAVE_PROJECT:
project.save()
message("")
message("=" * 72)
message("XS_A INTERVAL BLOCKS COMPLETE")
message("=" * 72)
message(
"Interval polygons created: {}".format(
written_count
)
)
message(
"Default symbology field: DISPLAY_CLASS"
)
message(
"Other available symbology fields include CONTAM_GROUP, "
"CLEANUP, CATEGORY, ANALYTICAL_STATUS, EXCEEDANCE_FLAG, "
"MTCA_SOIL, MTCA_GW, MTCA_SW, and MTCA_SEDIMENT."
)
message(
"Blocks use documented interval top and bottom depths."
)
message(
"Single-depth results are displayed as 0.5-foot bands."
)
message(
"Blocks are not extended through the full stick unless the "
"source record documents that entire interval."
)
message(
"Output feature class: {}".format(
output_feature_class
)
)
arcpy.ClearWorkspaceCache_management()
# =============================================================================
# SCRIPT ENTRY POINT
# =============================================================================
if __name__ == "__main__":
try:
main()
except Exception as error:
message(
"XS_A interval-block rebuild failed: {}".format(
error
),
2
)
message(
traceback.format_exc(),
2
)
try:
arcgis_messages = (
arcpy.GetMessages(2)
)
if arcgis_messages:
message(
arcgis_messages,
2
)
except Exception:
pass
try:
arcpy.ClearWorkspaceCache_management()
except Exception:
pass
raise
